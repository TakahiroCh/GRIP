import {ArrangeConfig, WasmModule} from "../models/WasmModule";
import {GraphLayout} from "../graph/GraphLayout";
import {Graph} from "nt-web-d3-graph";

const drawPanel = document.getElementById('draw-panel');
const WIDTH = drawPanel.clientWidth;
const HEIGHT = drawPanel.clientHeight;

const d3GraphConfig = {
  width: WIDTH,
  height: HEIGHT,
  graphId: drawPanel.id,
  element: drawPanel,
  currentNodeAppearence: 1,
  currentIconAppearence: 1,
  lineColor: '#000000',
  textColor: '#000000',
  fontSize: 17,
  vertex_mode: 'non',
  arrangement_mode: 'custom',
  graphdata: null
};

function displace(wasm: WasmModule, graphDotDescription: string): GraphLayout {
  const fromDot= GraphLayout.fromDot(graphDotDescription);
  // console.log('fromDot', fromDot);

  const cppDecr = fromDot.getCppDescription(wasm);
  // console.log('getCppDescription', cppDecr);

  let time = performance.now();

  const arr = wasm.arrange(cppDecr);
  // console.log('wasm.arrange', arr);

  time = (performance.now() - time)/1000;
  console.log('FULL TIME = ', time);

  const result = GraphLayout.fromCppDescription(arr);
  // console.log('result', result);

  // console.log('graphD3Description', result.getGraphD3Description());


  return result;

  // return GraphLayout.fromCppDescription(
  //   wasm.arrange(GraphLayout.fromDot(graphDotDescription).getCppDescription(wasm), cnf)
  // );
}

export function drawGraph(wasm: WasmModule, dotDescr: string) {
  const graph = displace(wasm, dotDescr);
  d3GraphConfig.graphdata = graph.getGraphD3Description();

  let graphInstance = new Graph(d3GraphConfig);
  graphInstance.arrange(d3GraphConfig.arrangement_mode);
}
