import {ArrangeConfig, WasmModule} from "../models/WasmModule";
import {CppVector} from "../models/CppVector";
import {CppVertexDecr} from "../models/CppVertexDecr";

export function loadWasm() {
  return new Promise<WasmModule>((resolve, reject) => {
    // @ts-ignore
    Module().then((module) => {
      delete module.then;
      resolve(bindWasmModule(module));
    });
  });
}

function bindWasmModule(module: any): WasmModule {
  return {
    ['module']: module,
    newVector$unsigned_int$(): CppVector<number> {
      return new module.vector$unsigned_int$();
    },
    newVector$VertexDesr$(): CppVector<CppVertexDecr> {
      return new module.vector$VertexDesc$();
    },
    arrange(vertices: CppVector<CppVertexDecr>): CppVector<CppVertexDecr> {
      return module.arrange(vertices);
    }
  };
}
