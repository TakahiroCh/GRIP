import {CppVector} from "./CppVector";
import {CppVertexDecr} from "./CppVertexDecr";

export interface ArrangeConfig {
  width: number;
  height: number;
  setRandom: boolean;
  forceIterNm: number;
  voronoiIterNm: number;
}

export interface WasmModule {
  module: any;
  newVector$unsigned_int$(): CppVector<number>;
  newVector$VertexDesr$(): CppVector<CppVertexDecr>;
  arrange(vertices: CppVector<CppVertexDecr>): CppVector<CppVertexDecr>;
}
