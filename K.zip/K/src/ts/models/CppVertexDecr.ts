import {CppVector} from "./CppVector";

export interface CppVertexDecr {
  id: number;
  label: string;
  x: number;
  y: number;
  vertices: CppVector<number>;
}
