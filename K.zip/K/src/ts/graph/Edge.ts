export class Edge {
  v: number;
  u: number;

  constructor(v: number, u: number) {
    this.v = v;
    this.u = u;
  }

  getNeighbour(id: number): number {
    return id == this.v ? this.u : this.v;
  }

}
