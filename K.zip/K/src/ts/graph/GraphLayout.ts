import {Vertex} from "./Vertex";
import {CppVector} from "../models/CppVector";
import {CppVertexDecr} from "../models/CppVertexDecr";
import {WasmModule} from "../models/WasmModule";
import {Edge} from "./Edge";

export class GraphLayout {
  vertices: Vertex[];

  constructor() {
    this.vertices = [];
  }

  addVertex(id: number, label: string): Vertex {
    const v = new Vertex(id, label);
    this.vertices.push(v);
    return v;
  }

  connect(uId: number, vId: number) {
    const edge = new Edge(uId, vId);
    this.vertices[uId].edges.push(edge);
    this.vertices[vId].edges.push(edge);
  }

  getCppDescription(wasm: WasmModule): CppVector<CppVertexDecr> {
    const vertices = wasm.newVector$VertexDesr$();
    this.vertices.forEach(v => vertices.push_back(v.getCppDescription(wasm)));
    return vertices;
  }

  static fromCppDescription(decr: CppVector<CppVertexDecr>): GraphLayout {
    const graph = new GraphLayout();
    const addedEdges = new Set<string>();
    for (let i = 0; i < decr.size(); i++) {
      graph.vertices.push(Vertex.fromCppDescription(decr.get(i), addedEdges));
    }
    return graph;
  }

  getGraphD3Description() {
    return {
      nodes: this.vertices.map(v => ({
        index: v.id,
        visible: true,
        name: v.label,
        fx: v.x,
        fy: v.y,
        fixed: true,
        id: 'n' + v.id,
        related_links: v.edges.map(e => 'n' + e.v + 'n' + e.u),
        related_nodes: v.getNeighboursIds().map(id => 'n' + id)
      })),
      links: this.getAllEdges()
    };
  }

  private getAllEdges(): any[] {
    const addedEdges = new Set<string>();
    const links = [];
    this.vertices.forEach(v => {
      v.edges.forEach(e => {
        if (!addedEdges.has('n' + e.v + 'n' + e.u)) {
          links.push({
            visible: true,
            id: 'n' + e.v + 'n' + e.u,
            source: e.v,
            target: e.u
          });
          addedEdges.add('n' + e.v + 'n' + e.u);
        }
      })
    });
    return links;
  }

  static fromDot(decr: string): GraphLayout {
    const graph = new GraphLayout();
    const lines = decr.split('\n');
    let linesCount = 0;
    const autoLabel = lines[linesCount++] == 'auto';
    if (autoLabel) {
      const num = +lines[linesCount++];
      for (let i = 0; i < num; i++) {
        graph.addVertex(i, '');
      }
    }
    for (; linesCount < lines.length; linesCount++) {
      if (!lines[linesCount]) {
        break;
      }
      const vv = lines[linesCount].split(' ');
      graph.connect(+vv[0], +vv[1]);
    }
    return graph;
  }
}
