import {CppVertexDecr} from "../models/CppVertexDecr";
import {WasmModule} from "../models/WasmModule";
import {Edge} from "./Edge";

export class Vertex {
  id: number;
  label: string;
  x: number;
  y: number;
  edges: Edge[];

  constructor(id: number, label: string) {
    this.id = id;
    this.label = label;
    this.x = this.y = 0;
    this.edges = [];
  }

  getNeighboursIds(): number[] {
    return this.edges.map(e => e.getNeighbour(this.id));
  }

  getCppDescription(wasm: WasmModule): CppVertexDecr {
    const vertices = wasm.newVector$unsigned_int$();
    this.getNeighboursIds().forEach(v => vertices.push_back(v));
    return {
      id: this.id,
      label: this.label,
      x: this.x,
      y: this.y,
      ['vertices']: vertices
    };
  }

  static fromCppDescription(decr: CppVertexDecr, addedEdges: Set<string>): Vertex {
    const vertex = new Vertex(null, null);
    vertex.id = decr.id;
    vertex.label = decr.label;
    vertex.x = decr.x;
    vertex.y = decr.y;
    vertex.edges = [];
    for (let i = 0; i < decr.vertices.size(); i++) {
      const first = vertex.id > decr.vertices.get(i) ? vertex.id : decr.vertices.get(i);
      const second = vertex.id > decr.vertices.get(i) ? decr.vertices.get(i) : vertex.id;
      if (!addedEdges.has('n' + first + 'n' + second)) {
        vertex.edges.push(new Edge(vertex.id, decr.vertices.get(i)));
        addedEdges.add('n' + first + 'n' + second);
      }
    }
    return vertex;
  }
}
