#ifndef T_POINT
#define T_POINT

#include <cmath>
#include <iostream>

struct Point {
private:
	double x;
	double y;

public:
	explicit Point(double x = 0, double y = 0);
	double getX() const;
	double getY() const;

	Point operator+(const Point& p) const;
	Point operator-(const Point& p) const;
	Point operator*(double k) const;
	Point operator/(double k) const;

	double norm() const;

	friend std::ostream& operator<<(std::ostream& out, const Point& point);
	//friend std::istream& operator>>(std::istream& in, Point& point);
};

#endif 
