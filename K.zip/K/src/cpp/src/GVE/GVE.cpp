#pragma once

#include "GVE.h"

Edge::Edge(unsigned int v1, unsigned int v2, unsigned int degree) : v1(v1), v2(v2), degree(degree) { }

unsigned int Edge::_1() const { return this->v1; }

unsigned int Edge::_2() const { return this->v2; }

unsigned int Edge::getDegree() const { return this->degree; }

unsigned int Edge::getNeighbhour(unsigned int v) const { return v == this->v1 ? this->v2 : this->v1; }

bool Edge::operator==(const Edge& e) const {
	return ((this->v1 == e._1() && this->v2 == e._2()) ||
		(this->v2 == e._1() && this->v1 == e._2()));
}

bool Edge::operator<(const Edge& e) const {
	return (this->v1 != e._1()) ? (this->v1 < e._1()) : (this->v2 < e._2());
}

std::ostream& operator<<(std::ostream& out, const Edge& e) {
	out << e._1() << " -- " << e._2() << "  " << e.getDegree();
	return out;
}



////////////////////////////////////////////////////////////////////////////////////////////////////////////////


Vertex::Vertex(Graph& graph, unsigned int id, const std::string name, const Point& position) : graph(graph), id(id), name(name), pos(position) {}

unsigned int Vertex::getId() const { return this->id; }

std::string Vertex::getName() const { return this->name; }

const Point Vertex::getPos() const { return this->pos; }

const std::vector<Edge> Vertex::getEdges() const { return this->edges; }

void Vertex::setPos(const Point pos) { this->pos = pos; }

void Vertex::connect(Vertex& other, unsigned int degree = 1) {
	Edge e(this->id, other.getId(), degree);
	this->edges.push_back(e);
}

Vertex& Vertex::find(Edge edge) {
	return this->graph.getVertex(edge.getNeighbhour(this->id));
}

std::vector<Vertex> Vertex::getNeighbours() {
	std::vector<Vertex> neighbours;
	for (Edge& edge : this->edges) {
		neighbours.push_back(find(edge));
	}
	return neighbours;
}

std::vector<unsigned int> Vertex::getNeighboursId() {
	std::vector<unsigned int> neighboursIds;
	for (Edge& edge : this->edges) {
		neighboursIds.push_back(edge.getNeighbhour(this->id));
	}
	return neighboursIds;
}

std::ostream& operator<<(std::ostream& out, const Vertex& v) {
	out << "ID" << v.getId() << " " << v.getName() << " " << v.getPos();
	return out;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////

Graph::Graph() {}

Graph::Graph(const std::vector<VertexDesc>& vertices) {
	for (VertexDesc v : vertices) {
		this->addVertex(v.name, Point(v.x, v.y));
	}
	std::set<std::pair<unsigned int, unsigned int>> edges;
	for (VertexDesc v : vertices) {
		for (unsigned int uID : v.vertices) {
			unsigned int first = v.id < uID ? v.id : uID;
			unsigned int second = v.id < uID ? uID : v.id;
			this->connect(first, second, 1);
		}
	}
}

const unsigned int Graph::getVertexSize() const {
	return this->vertices.size();
}

std::vector<Vertex> Graph::getVertexes() {
	return this->vertices;
}

std::vector<VertexDesc> Graph::getSimpleDescription() {
	std::vector<VertexDesc> output;
	for (Vertex& v : this->vertices) {
		output.push_back({ v.getId(), v.getName(), v.getPos().getX(), v.getPos().getY(), v.getNeighboursId() });
	}
	return output;
}

Vertex& Graph::getVertex(unsigned int id) {
	return this->vertices[id];
}

Vertex& Graph::addVertex(const std::string& name, const Point& pos) {
	this->vertices.emplace_back(*this, this->vertices.size(), name, Point(pos.getX(), pos.getY()));
	return this->vertices[this->vertices.size() - 1];
}

void Graph::connect(unsigned int id1, unsigned int id2, unsigned int degree) {
	this->vertices[id1].connect(this->vertices[id2], degree);
	this->vertices[id2].connect(this->vertices[id1], degree);
}

std::set<Edge> Graph::getEdges() {
	std::set<Edge> edges;
	for (Vertex& v : this->vertices) {
		for (const Edge& e : v.getEdges()) {
			edges.insert(e);
		}
	}
	return edges;
}






