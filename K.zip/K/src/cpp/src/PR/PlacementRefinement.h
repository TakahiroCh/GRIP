#pragma once

#ifndef T_PLACEMENT
#define T_PLACEMENT

#include "../GVE/GVE.h"
#include <deque>

class PlacementRefinement {
private:
	std::vector<unsigned int> depth;
	std::vector<unsigned int> nbr_size;
	std::vector < std::vector<std::vector<std::pair<unsigned int, int>>>> nbr;

	std::vector<Point> disp;
	std::vector<Point> oldDisp;
	std::vector<double> heat;
	std::vector<double> oldCos;
	int edgeLenght;
	double s;

	void setup_placement(Graph g, std::pair<std::vector<unsigned int>, std::deque<unsigned int>> misf);
	void setup_refinemet(Graph g, std::pair<std::vector<unsigned int>, std::deque<unsigned int>> misf);

	void set_depth(std::pair<std::vector<unsigned int>, std::deque<unsigned int>> misf);
	void set_nbr_size(Graph g, std::pair<std::vector<unsigned int>, std::deque<unsigned int>> misf);
	std::vector<unsigned int> set_Ni(Graph g, std::pair<std::vector<unsigned int>, std::deque<unsigned int>> misf,
		int misfLevel,
		unsigned int vertexID);
	void set_position(Graph* g, std::vector<unsigned int> threeClosestVertex, unsigned int vertexID);

	void intial_placement_start(Graph* g, std::pair<std::vector<unsigned int>, std::deque<unsigned int>> misf);
	void intial_placement_for(Graph* g, std::pair<std::vector<unsigned int>, std::deque<unsigned int>> misf, int vLevel);

	void refinement_for(Graph* g, std::pair<std::vector<unsigned int>, std::deque<unsigned int>> misf, int vLevel);
	Point Fruchterman_Reingold(Graph* g, int vLevel, unsigned int vertexID);
	Point Kamada_Kawai(Graph* g, int vLevel, unsigned int vertexID);
	void update_local_temp(unsigned int vertexID);

	double dist(const Vertex* u, const Vertex* v);

public:

	void placement_and_refinement(Graph* g, std::pair<std::vector<unsigned int>, std::deque<unsigned int>> misf);
	void stdOut();
};

#endif
