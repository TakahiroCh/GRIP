#include "PlacementRefinement.h"

#include <algorithm>
#include <list>
#include <math.h>
#include <random>

void PlacementRefinement::setup_placement(Graph g, std::pair<std::vector<unsigned int>, std::deque<unsigned int>> misf) {
	this->nbr = std::vector<std::vector<std::vector<std::pair<unsigned int, int>>>>(g.getVertexSize(),
		std::vector<std::vector<std::pair<unsigned int, int>>>(misf.second.size(),
			std::vector<std::pair<unsigned int, int>>()));
	this->set_depth(misf);
	this->set_nbr_size(g, misf);
}

void PlacementRefinement::setup_refinemet(Graph g, std::pair<std::vector<unsigned int>, std::deque<unsigned int>> misf) {
	this->edgeLenght = 8;
	this->s = 0.05;
	this->disp = std::vector<Point>(g.getVertexSize());
	this->oldDisp = std::vector<Point>(g.getVertexSize());
	this->heat = std::vector<double>(g.getVertexSize(), this->edgeLenght/6);
	this->oldCos = std::vector<double>(g.getVertexSize());
}

void PlacementRefinement::set_depth(std::pair<std::vector<unsigned int>, std::deque<unsigned int>> misf) {
	std::vector<unsigned int> misFiltration = misf.first;
	std::deque<unsigned int> misBorder = misf.second;
	int sizeMisfFiltration = misFiltration.size();
	int sizeMisBorder = misBorder.size();
	this->depth = std::vector<unsigned int>(sizeMisfFiltration);
	for (int level = 0, i = 0; i < sizeMisfFiltration; i++) {
		if (i == misf.second.at(level)) {
			level++;
		}
		this->depth[misFiltration[i]] = (sizeMisBorder - 1 - level);
	}
}

void PlacementRefinement::set_nbr_size(Graph g, std::pair<std::vector<unsigned int>, std::deque<unsigned int>> misf) {
	std::vector<unsigned int> misFiltration = misf.first;
	std::deque<unsigned int> misBorder = misf.second;
	int sizeMisBorder = misBorder.size();
	this->nbr_size = std::vector<unsigned int>(sizeMisBorder);
	int aveDeg = 0;
	for (Vertex& v : g.getVertexes()) {
		aveDeg += v.getEdges().size();
	}
	//std::cout << aveDeg << " AveDeg ";
	int sizeVertexes = g.getVertexSize();
	aveDeg = (int)(aveDeg / sizeVertexes);
	//std::cout << aveDeg << '\n';

	for (int i = 0; i < sizeMisBorder; i++) {
		//std::cout << (int)(aveDeg * sizeVertexes / misBorder[sizeMisBorder - 1 - i]) << " or " << (int)misBorder[sizeMisBorder - 1 - i] - 1 << '\n';
		this->nbr_size[i] = std::min((int)(aveDeg * sizeVertexes / misBorder[sizeMisBorder - 1 - i]), (int) misBorder[sizeMisBorder - 1 - i] - 1);
	}
}

//misfLevel is index of vector in misFiltration
std::vector<unsigned int> PlacementRefinement::set_Ni(Graph g, std::pair<std::vector<unsigned int>, std::deque<unsigned int>> misf,
		int misfLevel,
		unsigned int vertexID)
{
	std::vector<unsigned int> closestVertexes;

	std::set<unsigned int> uniqueSorted = std::set<unsigned int>(misf.first.begin(), misf.first.begin() + misfLevel);
	std::vector<int> markers = std::vector<int>(misf.first.size(), 0);
	markers[vertexID] = -1;

	std::list<std::pair<unsigned int, int>> queue;
	queue.push_back({ vertexID, 1 });

	std::list<unsigned int>::iterator i;

	while (!queue.empty()) {
		unsigned int current_id = queue.front().first;
		int current_depth = queue.front().second;
		queue.pop_front();

		Vertex current_vertex = g.getVertex(current_id);
		for (unsigned int neighbour : current_vertex.getNeighboursId()) {
			if (markers[neighbour] == 0) {
				markers[neighbour] = -1;
				queue.push_back({ neighbour, current_depth + 1 });

				int maxIndexInNi = this->depth[neighbour];
				for (int i = 0; i <= maxIndexInNi; i++) {
					if (this->nbr[vertexID][i].size() != this->nbr_size[i]) {
						this->nbr[vertexID][i].push_back({ neighbour, current_depth });
					}
				}

				if (uniqueSorted.find(neighbour) != uniqueSorted.end()) {
					if (closestVertexes.size() != 3) {
						closestVertexes.push_back(neighbour);
					}
				}
			}
		}
	}

	return closestVertexes;
}

void PlacementRefinement::set_position(Graph* g, std::vector<unsigned int> threeClosestVertex, unsigned int vertexID) {
	Vertex& currentVertex = g->getVertex(vertexID);
	Point currentPos(0, 0);

	for (unsigned int& vertexId : threeClosestVertex) {
		Point currentClosestPoint = g->getVertex(vertexId).getPos();
		currentPos = currentPos + currentClosestPoint;
	}

	currentPos = currentPos / threeClosestVertex.size();
	currentVertex.setPos(currentPos);
}

void PlacementRefinement::intial_placement_start(Graph* g, std::pair<std::vector<unsigned int>, std::deque<unsigned int>> misf)  {
	for (int i = 0; i < 3; i++) {
		set_Ni(*g, misf, 0, misf.first[i]);
	}
}

void PlacementRefinement::intial_placement_for(Graph* g, std::pair<std::vector<unsigned int>, std::deque<unsigned int>> misf, int vLevel) {
	std::vector<unsigned int> misFiltration = misf.first;
	std::deque<unsigned int> misBorder = misf.second;
	int finishIndex = misBorder.size() - vLevel - 1;
	unsigned int start = misBorder[finishIndex - 1];
	unsigned int finish = misBorder[finishIndex];
	for (unsigned int i = start; i < finish; i++) {
		std::vector<unsigned int> result = set_Ni(*g, misf, i, misf.first[i]);
		this->set_position(g, result, misf.first[i]);
	}
}

void PlacementRefinement::refinement_for(Graph* g, std::pair<std::vector<unsigned int>, std::deque<unsigned int>> misf, int vLevel) {
	std::vector<unsigned int> misFiltration = misf.first;
	std::deque<unsigned int> misBorder = misf.second;
	int sizeMisBorder = misBorder.size();

	int finishIndexMisBorder = sizeMisBorder - vLevel - 1;
	int finishIndex = misBorder.at(finishIndexMisBorder);
	for (int i = 0; i < finishIndex; i++) {
		unsigned int currentVertexId = misFiltration[i];
		if (vLevel > 0) {
			this->disp[currentVertexId] = Kamada_Kawai(g, vLevel, currentVertexId);
		}
		else {
			this->disp[currentVertexId] = Fruchterman_Reingold(g, vLevel, currentVertexId);
		}
		update_local_temp(currentVertexId);
		this->oldDisp[currentVertexId] = this->disp[currentVertexId];
		double disNorm = this->disp[currentVertexId].norm();
		if (disNorm != 0) {
			this->disp[currentVertexId] = (this->disp[currentVertexId] * this->heat[currentVertexId]) / disNorm;
		}
	}
	for (int i = 0; i < finishIndex; i++) {
		Vertex& current_vertex = g->getVertex(misFiltration[i]);
		current_vertex.setPos(current_vertex.getPos() + this->disp[misFiltration[i]]);
	}
}

double PlacementRefinement::dist(const Vertex* u, const Vertex* v) {
	Point pU = u->getPos();
	Point pV = v->getPos();
	return std::sqrt(std::pow(pU.getX() - pV.getX(), 2) + std::pow(pU.getY() - pV.getY(), 2));
}

Point PlacementRefinement::Kamada_Kawai(Graph* g, int vLevel, unsigned int vertexID) {
	Point currentSum(0,0);
	int sizeNbr = this->nbr[vertexID][vLevel].size();
	Vertex v = g->getVertex(vertexID);
	for (int i = 0; i < sizeNbr; i++) {
		std::pair<unsigned int, int> vertexAndDist = this->nbr[vertexID][vLevel][i];
		Vertex u = g->getVertex(vertexAndDist.first);
		Point currentPoint = u.getPos() - v.getPos();
		long delimiter = (vertexAndDist.second * edgeLenght * edgeLenght);
		double k = (this->dist(&u, &v) / delimiter) - 1;
		currentSum = currentSum + (currentPoint * k);
	}

	return currentSum;
}

Point PlacementRefinement::Fruchterman_Reingold(Graph* g, int vLevel, unsigned int vertexID) {
	Point currentSum(0, 0);
	int sizeNbr = this->nbr[vertexID][vLevel].size();
	Vertex v = g->getVertex(vertexID);
	for (int i = 0; i < sizeNbr; i++) {
		Vertex u = g->getVertex(this->nbr[vertexID][vLevel][i].first);
		Point currentPoint = v.getPos() - u.getPos();
		double distance = this->dist(&u, &v);
		double k = this->s * (edgeLenght / distance) * (edgeLenght * distance);
		currentSum = currentSum + (currentPoint * k);
	}

	for (Vertex u : v.getNeighbours()) {
		Point currentPoint = u.getPos() - v.getPos();
		double distance = this->dist(&u, &v);
		double k = (distance / edgeLenght) * (distance / edgeLenght);
		currentSum = currentSum + (currentPoint * k);
	}

	return currentSum;
}

void PlacementRefinement::update_local_temp(unsigned int vertexID) {
	Point disp = this->disp[vertexID];
	Point oldDisp = this->oldDisp[vertexID];
	double dispNorm = disp.norm();
	double oldDispNorm = oldDisp.norm();
	if (dispNorm != 0 && oldDispNorm != 0) {
		double cos = (disp.getX() * oldDisp.getX() + disp.getY() * oldDisp.getY()) / (dispNorm * oldDispNorm);
		double r = 0.15;
		double constant_s = 3;
		if (this->oldCos[vertexID] * cos > 0) {
			this->heat[vertexID] += (cos * r * constant_s);
		} else {
			this->heat[vertexID] += (cos * r);
		}
		this->oldCos[vertexID] = cos;
	}
}

void PlacementRefinement::placement_and_refinement(Graph* g, std::pair<std::vector<unsigned int>, std::deque<unsigned int>> misf) {
	this->setup_placement(*g, misf);
	this->setup_refinemet(*g, misf);
	this->set_depth(misf);
	this->set_nbr_size(*g, misf);
	int sizeMisBorder = misf.second.size();
	for (int i = sizeMisBorder - 1; i >= 0; i--) {
		std::cout << "Stage - " << i << "\n";
		if (i == sizeMisBorder - 1) {
			this->intial_placement_start(g, misf);
		} else {
			this->intial_placement_for(g, misf, i);
		}
		int rounds = 5 + (std::rand() % (26));
		while (rounds >= 0) {
			this->refinement_for(g, misf, i);
			rounds--;
		}
	}
}


void PlacementRefinement::stdOut() {
	int i = 0;
	for (auto& value1 : this->nbr) {
		int j = 0;
		std::cout << "Vertex" << i++ << " ->\n";
		for (auto& value2 : value1) {
			std::cout << "\tN" << j++ << " -> ";
			for (auto& value3 : value2) {
				std::cout << "\t\t" << value3.first << " -- " << value3.second;
			}
			std::cout << '\n';
		}
	}

	i = 0;
	for (auto& value : this->depth) {
		std::cout << "Vertex -> Depth ; " << i++ << " -> " << value  << "\n";
	}
}





