#ifndef T_MISF
#define T_MISF

#include "../GVE/GVE.h"

#include <vector>
#include <deque>

class MISFiltration {
public:
	std::vector<int> bsf(Graph g, std::vector<int> markers, std::set<unsigned int> uniqueSorted, const unsigned int v, const unsigned int level);
	std::pair<std::vector<unsigned int>, std::deque<unsigned int>> misf(Graph g);
};

#endif 