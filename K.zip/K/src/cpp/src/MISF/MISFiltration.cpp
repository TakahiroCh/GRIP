#include "MISFiltration.h"

#include <utility>
#include <list>
#include <numeric>
#include <algorithm>



std::vector<int> MISFiltration::bsf(Graph g, std::vector<int> markers, std::set<unsigned int> uniqueSorted, const unsigned int id, const unsigned int level) {
    double depth = std::pow(2, level);
    markers[id] = -1;

    std::list<std::pair<unsigned int, double>> queue;
    queue.push_back({ id, 0 });

    std::list<unsigned int>::iterator i;

    while (!queue.empty()) {
        unsigned int current_id = queue.front().first;
        double current_depth = queue.front().second;
        queue.pop_front();

        if (current_depth > depth) break;

        Vertex current_vertex = g.getVertex(current_id);
        if (uniqueSorted.find(current_id) != uniqueSorted.end()) {
            for (unsigned int neighbours : current_vertex.getNeighboursId()) {
                if (markers[neighbours] == 0) {
                    markers[neighbours] = -1;
                    queue.push_back({ neighbours, current_depth + 1 });
                }
            }
        }
    }
    
    markers[id] = 1;
    return markers;
}

std::pair<std::vector<unsigned int>, std::deque<unsigned int>> MISFiltration::misf(Graph g) {
    unsigned int size = g.getVertexSize();
    if (size == 0) {
        return {};
    }
    unsigned int log_2_n = ilogb(size) + 2;
    unsigned int sorted = 0;
    std::vector<unsigned int> misFiltration = std::vector<unsigned int>(size);
    std::iota(misFiltration.begin(), misFiltration.end(), 0);
    std::deque<unsigned int> misBorder = std::deque<unsigned int>();
    misBorder.push_front(size);


    for (unsigned int level = 1; level < log_2_n; level++) {
        if (sorted == size) {
            break;
        }
        std::vector<int> markers = std::vector<int>(size, 0);
        unsigned int current_size = misBorder.front();
        std::set<unsigned int> uniqueSorted = std::set<unsigned int>(misFiltration.begin(), misFiltration.begin() + current_size);
        std::set<unsigned int> replacement;
        for (unsigned int i = 0; i < current_size; i++) {
            if (markers[misFiltration[i]] == 0) {
                replacement.insert(misFiltration[i]);
                markers = this->bsf(g, markers, uniqueSorted, misFiltration[i], level);
                sorted++;
            }
        }

        std::set<unsigned int> difference;
        std::set_difference(std::begin(uniqueSorted), std::end(uniqueSorted),
            std::begin(replacement), std::end(replacement),
            std::inserter(difference, std::begin(difference)));
        std::copy(std::begin(replacement), std::end(replacement), std::begin(misFiltration));
        std::copy(std::begin(difference), std::end(difference), std::begin(misFiltration) + replacement.size());

        if (size > sorted + 3) misBorder.push_front(size - sorted);
    }

    misBorder.push_front(3);


    return { misFiltration, misBorder };
}
