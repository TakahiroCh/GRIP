﻿#include <iostream>
#include <vector>
#include <numeric>

#include "GVE.h"
#include "MISFiltration.h"
#include "PlacementRefinement.h"

using namespace std;

vector<VertexDesc> arrage(const std::vector<VertexDesc>& vertices) {
    Graph g(vertices);
    MISFiltration m;
    std::pair<std::vector<unsigned int>, std::deque<unsigned int>> misf = m.misf(g);
    PlacementRefinement p;
    p.placement_and_refinement(&g, misf);
    return g.getSimpleDescription();
}


#include <emscripten/bind.h>
using namespace emscripten;

EMSCRIPTEN_BINDINGS() {
    function("arrange", &arrange);

    value_object<VertexDesc>("VertexDesc")
        .field("id", &VertexDesc::id)
        .field("label", &VertexDesc::name)
        .field("x", &VertexDesc::x)
        .field("y", &VertexDesc::y)
        .field("vertices", &VertexDesc::vertices)
        ;
    register_vector<VertexDesc>("vector<VertexDesc>");

    register_vector<unsigned int>("vector<unsigned_int>");
}

int main() {
    /*vector<VertexDesc> vertices = {
        {0, "v0", 1, 2, {1, 2}},
        {1, "v1", 3, 4, {0, 2}},
        {2, "v2", 5, 6, {0, 4, 5}},
        {3, "v3", 7, 8, {4}},
        {4, "v4", 9, 10, {2, 3}},
        {5, "v5", 11, 12, {2}}
    };

    vector<VertexDesc> result = arrage(vertices);
    for (VertexDesc& v : result) {
        cout << v.x << " " << v.y << '\n';
    }*/
    return 0;
}