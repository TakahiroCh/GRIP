import {Graph} from "./graph";

Graph.prototype.linear_arrangement = (graph) => {
    let result = {};

    let subgraph = graph;
    let yCoord = -subgraph.length / 2.;
    for (let j = 0; j < subgraph.length; j += 1) {
        result[subgraph[j].id] = {};
        result[subgraph[j].id].x = 0;
        result[subgraph[j].id].y = yCoord;
        yCoord += 1;
    }

    return result;
};

Graph.prototype.circular_arrangement = (graph) => {
    let result = {};

    let subgraph = graph;

    let r = Math.ceil(subgraph.length / 4.);
    console.log('r=', r);
    console.log('n = ', subgraph.length, subgraph[subgraph.length - 1]);
    let x = 0;
    let y =  -r;


    //верхняя и нижняя вершины на окружности
    result[subgraph[0].id] = {};
    result[subgraph[0].id].x = x;
    result[subgraph[0].id].y = -y;

    result[subgraph[subgraph.length - 1].id] = {};
    result[subgraph[subgraph.length - 1].id].x = x;
    result[subgraph[subgraph.length - 1].id].y = y;

    //все остальные вершины, находящиеся на одной высоте, парами
    for (let j = 1; j < subgraph.length - 1; j += 2) {
        y += 1;
        x = Math.sqrt((Math.pow(r, 2) - Math.pow(y, 2)));

        result[subgraph[j].id] = {};
        result[subgraph[j].id].x = x;
        result[subgraph[j].id].y = y;

        if (j + 1 < subgraph.length - 1) {
            result[subgraph[j + 1].id] = {};
            result[subgraph[j + 1].id].x = -x;
            result[subgraph[j + 1].id].y = y;
        }
    }

    return result;
};

Graph.prototype.scale_coords = (graph, coords, scale) => {
    if (!graph) {
        return;
    }

    for (let node of graph.nodes) {
        node.x = coords[node.id].x * scale;
        node.y = coords[node.id].y * scale;

        node.fx = node.x;
        node.cx = node.x;
        node.px = node.x;

        node.fy = node.y;
        node.cy = node.y;
        node.py = node.y;

        node.fixed = true;
        node.xcenter = 0;
    }
};

Graph.prototype.circumscribed_size = subgraph => {
    let left_x   = 0,
        right_x  = 0,
        top_y    = 0,
        bottom_y = 0;

    for (let node of subgraph) {
        if (node.x < left_x) {
            left_x = node.x;
        }
        if (node.x > right_x) {
            right_x = node.x;
        }
        if (node.y < bottom_y) {
            bottom_y = node.y;
        }
        if (node.y > top_y) {
            top_y = node.y;
        }
    }

    console.log('left_x, right_x, top_y, bottom_y',left_x,right_x,top_y,bottom_y);
    return {'width': Math.abs(right_x - left_x), 'height': Math.abs(top_y - bottom_y) }

};

Graph.prototype.countMatrix = (comp_num) => {
    let a = Math.sqrt(comp_num);
    let a_f = Math.floor(a);
    let a_c = Math.ceil(a);

    if (a_f * a_f >= comp_num) {
        return {'columns': a_f, 'lines': a_f};
    }
    if (a_f * a_c >= comp_num) {
        return {'columns': a_c, 'lines': a_f};
    }
    return {'columns': a_c, 'lines': a_c};
};

Graph.prototype.translate_vertex = (node, vector) => {
    node.x = node.x + vector.x;
    node.y = node.y + vector.y;

    node.fx = node.x;
    node.cx = node.x;
    node.px = node.x;

    node.fy = node.y;
    node.cy = node.y;
    node.py = node.y;

    node.fixed = true;
    node.xcenter = vector.x;
};

Graph.prototype.count_depth_bfs = (root, graph) => {
    let node;

    for (let i = 0; i < graph.length; i += 1) {
        if (graph[i].id == root.id) {
            node = i;
            graph[i].depth = 0;
            break;
        }
    }

    var qH = 0, qT = 0;
    var queue = [];
    var v;

    queue[qT++] = node;

    graph[node].depthed = true;

    while (qH < qT) { // пока очередь не пуста
        v = queue[qH++]; // извлекаем текущую вершину
        for (var nv = 0; nv < graph.length; nv += 1) { // перебираем вершины
            // console.log(v, nv, queue);
            if (!graph[nv].depthed &&
                (graph[v].related_nodes.indexOf(graph[nv].id) != -1 || graph[nv].related_nodes.indexOf(graph[v].id) != -1)) { // если nv не помечена и смежна с v
                /* <обработка вершины nv> */
                graph[nv].depthed = true; // помечаем ее
                graph[nv].depth = graph[v].depth + 1;
                queue[qT++] = nv; // и добавляем в очередь

            }
        }
    }

    for (let node of graph) {
        node.depthed = false;
    }
};

Graph.prototype.find_root = (graph) => {
    let root = graph[0];
    let not_list_children_max = 0;
    let max_node_weight = 0;


    for (let node of graph) {
        let not_list_children = 0;
        let node_weight = 0;
        for (let child of graph) {
            if (node.related_nodes.indexOf(child.id) != -1 && child.related_nodes.length != 1 && node.related_nodes.length != 1) {
                not_list_children += 1;
                node_weight += child.related_nodes.length
            }
        }
        if (not_list_children > not_list_children_max && node_weight > max_node_weight ) {
            not_list_children_max = not_list_children;
            max_node_weight = node_weight;
            root = node;
        }
    }

    return root;
};

Graph.prototype.tree_arrangement = (graph, subgraph_num) => {
    let result = {};
    let subgraph = graph;


    let root = Graph.prototype.find_root(subgraph);
    // root = subgraph[0];
    Graph.prototype.count_depth_bfs(root, subgraph);


    let x = 0;
    let y = 0;
    result[root.id] = {};
    result[root.id].x = x;
    result[root.id].y = y;

    let levels_num = 0;
    for (let node of subgraph) {
        if (node.depth > levels_num) {
            levels_num = node.depth;
        }
    }

    let max_level_size = 0;
    for (let j = 0; j <= levels_num; j++){
        let curr_level_size = subgraph.filter(d => d.depth == j).length;
        if (curr_level_size > max_level_size ) {
            max_level_size = curr_level_size;
        }
    }

    let max_name_length = 0;

    for (let i = 0; i < subgraph.length; i += 1) {
        if (subgraph[i].name && subgraph[i].name.length > max_name_length) {
            max_name_length = subgraph[i].name.length;
        }
    }

    let column_dist = max_name_length;
    if (max_name_length === 0) {
        column_dist = 9;
    }


    let level_y = [];
    let level_x = [];
    let level_step = [];
    let level_shift = [];
    for (let j = 0; j <= levels_num; j++) {
        level_x[j] = j*column_dist;
        level_y[j] = 0;
        let level = subgraph.filter(d => d.depth == j);
        level_step[j] = max_level_size / level.length;
        level_shift[j] = 0;
    }

    let node;

    for (let j = 0; j < subgraph.length; j += 1) {
        if (subgraph[j].id == root.id) {
            node = j;
            subgraph[j].depth = 0;
            break;
        }
    }

    let qH = 0, qT = 0;
    let queue = [];
    let v;

    queue[qT++] = node;

    subgraph[node].tree = true;

    let i = 0;

    while (qH < qT) { // пока очередь не пуста
        v = queue[qH++]; // извлекаем текущую вершину
        for (var nv = 0; nv < subgraph.length; nv += 1) { // перебираем вершины
            // console.log('ii = ', i++);
            // console.log(v, nv, queue);
            // console.log(!subgraph[nv].tree, subgraph[v].related_nodes.indexOf(subgraph[nv].id));
            if (!subgraph[nv].tree && subgraph[v].related_nodes.indexOf(subgraph[nv].id) != -1) { // если nv не помечена и смежна с v
                /* <обработка вершины nv> */
                subgraph[nv].tree = true; // помечаем ее
                result[subgraph[nv].id] = {};
                result[subgraph[nv].id].x = level_x[subgraph[nv].depth]; // + level_shift[subgraph[nv].depth];
                result[subgraph[nv].id].y = level_y[subgraph[nv].depth];
                level_y[subgraph[nv].depth] += level_step[subgraph[nv].depth];
                queue[qT++] = nv; // и добавляем в очередь

                // if (level_shift[subgraph[nv].depth] == 0) {
                //     level_shift[subgraph[nv].depth] = 1;
                // } else {
                //     level_shift[subgraph[nv].depth] = -level_shift[subgraph[nv].depth];
                // }
            }
        }
    }

    for (let node of subgraph) {
        node.tree = false;
    }

    return result;
};

// gap - желаемое расстояние между компонентами по горизонтали
// zero_place = 1. - точка (0,0) компоненты расположена в левом верхнем углу
//            = 2. - точка (0,0) расположена внутри компоненты
Graph.prototype.tiling = (graph, comp_num, gap, zero_place) => {
    let translate_vectors = [];
    let x = 0;
    let y = 0;
    let cur_max_height = 0;
    let prev_max_height = 0;
    let comp_counter = 0;
    let ys = []; // остступы между строками матрицы, ys[0] = 0

    // вычисляем, во сколько строк и столбцов квадратной матрицы можно уложить все компоненты
    let matrixSize = Graph.prototype.countMatrix(comp_num);

    // цикл расставляет сдвиги по x каждой компоненты для расположения их в клетках матрицы
    // и вычисляет сдвиги по y для каждой строки матрицы
    for (let i = 0; i < matrixSize.lines; i += 1) {
        x = 0; // текущий сдвиг по x - обнуляется на новой строке
        for (let j = 0; j < matrixSize.columns; j += 1) { //бежим по столбцам
            // отфильтровываем очередную компоненту
            let component = graph.filter(d => {
                return d.component == comp_counter
            });
            // вычисляем ширину и высоту описывающего прямоугольника
            let componentSize = Graph.prototype.circumscribed_size(component);

            // ищем самую "высокую" компоненту в строке,
            // сдвиг следующей строки будет зависеть от этой высоты
            // и от такой же высоты предыдущей строки
            if (componentSize.height > cur_max_height) {
                cur_max_height = componentSize.height;
            }

            // сдвиг это компоенты равен x
            // на предыдушем шаге цыкла его увеличили на ширину предыдущей компоненты
            if (j !== 0) {
                translate_vectors[comp_counter] = {'x': x + gap};
                x += gap;
            } else { // сдвиги элементов (i,0) сразу известны и равны нулю
                translate_vectors[comp_counter] = {'x': 0};
            }

            //если компонента уложена в столбец, то следующую сдвинем минимум на gap
            if (componentSize.width == 0) {
                x += gap;
            } else { //иначе, сдвинем следующую на велиничу, зависящцю от ширины текущей компоненты
                x += componentSize.width/zero_place;

            }

            // на следющем шаге переходим к следующей компоненте
            comp_counter += 1;
        }

        // если это нулевая строка, то ее никуда не двигаем
        if (i == 0) {
            ys[i] = 0;
        } else {
            // если все компоненты в этой строке уложены по линии
            // то следующую строку двигаем хотя бы на четверть гэпа (горизонтального прогала)
            if (cur_max_height == 0){cur_max_height = gap/4.};

            //относительно предыдущей строки
            // сдвигаем на максимальную высоту той строки и максимальную высоту текущей
            // (либо на половины высот, зависит от конфигурации компонеты)
            ys[i] = ys[i - 1] + cur_max_height/zero_place + prev_max_height/zero_place + gap/5.;
        }

        // текущая высота становится предыдущей
        prev_max_height = cur_max_height + 0;
        // сюда будем искать новую текущую
        cur_max_height = 0;

    }

    // теперь мы знаем все межстрочные расстояния (сдвиги по y) - раздадим их компонентам
    // перебираем все компонеты заново
    comp_counter = 0;
    for (let i = 0; i < matrixSize.lines; i += 1) {
        for (let j = 0; j < matrixSize.columns; j += 1) {
            translate_vectors[comp_counter].y = ys[i];
            comp_counter += 1;
        }

    }

    // сдвигаем координаты каждой вершины в зависимости от компоненты
    for (let node of graph) {
        Graph.prototype.translate_vertex(node, translate_vectors[node.component]);
    }
};

Graph.prototype.rearrange = (nodeGraph, mode, fontSize) => {
    console.log('rearrange ');

    let components_number = Graph.prototype.componentSearch(nodeGraph.nodes);

    let coords = {};
    let subgraph;

    switch (mode) {
        case 'linear':
            for (let i = 0; i < components_number; i++) {
                subgraph = nodeGraph.nodes.filter(d => d.component == i);
                coords = Object.assign(coords, Graph.prototype.linear_arrangement(subgraph));
            }
            Graph.prototype.scale_coords(nodeGraph, coords, fontSize);
            Graph.prototype.tiling(nodeGraph.nodes, components_number, fontSize*10, 2.);

            break;
        case 'circular':
            for (let i = 0; i < components_number; i++) {
                subgraph = nodeGraph.nodes.filter(d => d.component == i);
                coords = Object.assign(coords, Graph.prototype.circular_arrangement(subgraph));
            }

            Graph.prototype.scale_coords(nodeGraph, coords, fontSize);
            Graph.prototype.tiling(nodeGraph.nodes, components_number, fontSize*20, 2.);

            break;
        case 'tree':
            for (let i = 0; i < components_number; i++) {
                subgraph = nodeGraph.nodes.filter(d => d.component == i);
                coords = Object.assign(coords, Graph.prototype.tree_arrangement(subgraph, components_number));
            }

            Graph.prototype.scale_coords(nodeGraph, coords, fontSize);
            Graph.prototype.tiling(nodeGraph.nodes, components_number, fontSize*20, 1.);
            break;

        // case 'intersection':
        //     let colorsNum = 0;
        //     for (let i =0; i < nodeGraph.nodes.length; i++) {
        //         if (nodeGraph.nodes[i].color > colorsNum ) {
        //             colorsNum = nodeGraph.nodes[i].color;
        //         }
        //     }
        //     if (colorsNum > 0) {
        //         for (let i = 0; i < colorsNum; i++) {
        //             subgraph = nodeGraph.nodes.filter(d => d.color == i);
        //             coords = Object.assign(coords, $scope.circular_arrangement(subgraph, components_number));
        //         }
        //     } else {
        //         subgraph = nodeGraph.nodes;
        //         coords = Object.assign(coords, $scope.circular_arrangement(subgraph, components_number));
        //     }
        //
        //
        //     $scope.scale_coords(nodeGraph, coords, $scope.fontSize);
        //     $scope.tiling(nodeGraph.nodes, components_number, $scope.fontSize*40, 1.);
        //     this.center_view();
        //     break;

        case 'none':
            break;
    }
};