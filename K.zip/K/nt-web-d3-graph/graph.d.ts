declare class Graph {
    constructor (configurations: any);

    arrange (key: any): void;
    center_view (): void;
    onResize (): void;
    arrange (key: string): void;
    isSelected (): boolean;
    isDeleted (): boolean;
    showDeletedNodes (): void;
    hideSelectedNodes (): void;
    hideUnSelectedNodes (): void;
    filterSelectedNodes (): void;
    filterUnSelectedNodes (): void;
    nodeChange (vertexDegree: number): void;
    linkChange (linkDegree: number): void;
    changeIconAppearance (view: number): void;
    changeNodeAppearance (view: number): void;
    copySelected (): void;
    inverseSelection (): void;
    selectConnectedComponent (): void;
    nodeChangeSelected (nodeDistinctSize: number): void;
}

export {Graph};