import * as d3 from 'd3';

export class Graph {
    constructor (configurations) {
        /*
                configuration = {
                    graphdata // структура графа {nodes: [], links: []}

                    'arrangement_mode': 'tree', // тип размещения
                    // normal - иконка человечек,
                    // other - иконка-диаграмма,
                    // picture - картинка,
                    // non - только подпись
                    // custom - пользовательское

                    // функция пользовательского размещения
                    'customArrangement': (graph) => {},

                    // коэффициенты для изменения размеров вершин и ребер
                    'vertex_weight': 0,
                    'edge_weight': 0,

                    // вид вершины
                    // normal - иконка человечек,
                    // other - иконка-диаграмма,
                    // picture - картинка,
                    // non - только подпись
                    'currentIconAppearance': "normal",

                    // показать вес
                    'showDegree': false,

                    // хранящиеся параметры фильтрации
                    'min_neighbor': 0,
                    'substring': '',

                    // параметр для поиска вершин
                    // 'search_substring': '',

                    // id для присвоения svg элементу
                    'svgId': this.resultGraphService.svgId,

                    // вызывается при инициализации графа
                    // передается объект графа
                    onInitialized: e => { },

                    // вызывается при измении видимости или выделения вершин
                    // функции для налаживания кроссфильтрации
                    'onChange': (changes) => { },

                    // возвращает цвет, которым нужно окрасить текущую вершину
                    'getColor': (node) => { },

                    // возвращает цвет, которым нужно окрасить текущее ребро
                    'getLineColor': (link) => { },

                    // возвращает true, если вершину нужно отрисовать специальным образом
                    'specialView': (node) => { },

                    // получает вершину и возвращает адрес изображения, для отображения этой вершины
                    // 'getPicture': (node) => { },

                    // вызывается при каждом изменении числа отображаемых вершин
                    'processVisibleNodes': () => { }

                    // позиции, на которых надо сохранять узлы
                    // идентификация по staticId - необходим у узлов
                    'nodeTranslateMap': {id: {x, y, bool?}}
                };
        */

        this.configurations=configurations;
        this.linksMap = {};


        this.minNeighbourNodesNumber = 1;
        if (this.configurations.minNodeDegree) {
            this.minNodeDegree = this.configurations.minNodeDegree;
        } else {
            this.minNodeDegree = 0;
        }
        this.searchPattern = "";
        this.suffixRegex = "";
        if (this.configurations.imageRadius) {
            this.imgR = this.configurations.imageRadius;
        } else {
            this.imgR = 5;
        }

        if (this.configurations.lineColor) {
            this.lineColor = this.configurations.lineColor;
        } else {
            this.lineColor = "#AAAAAA";
        }

        if (this.configurations.fontSize) {
            this.fontSize = this.configurations.fontSize;
        } else {
            this.fontSize = 10;
        }

        if (this.configurations.textColor) {
            this.textColor = this.configurations.textColor;
        } else {
            this.textColor = "#878787";
        }

        this.nodeDistinctSize = this.fontSize;
        this.filterMap = {'neighbour': (n) => false, 'substring': (n) => false, 'degree': (n) => false}; //переменная, для совместного применения фильтров
        this.filterIds = {};
        this.color = d3.scaleOrdinal(d3.schemeCategory10);
        this.width = this.configurations.width;
        this.height = this.configurations.height;
        this.force = null;
        this.simulation = null;
        this.node = null;
        this.link = null;
        this.shiftKey = null;
        this.ctrlKey = null;
        this.delKey = null;
        this.brush = null;
        this.brusher = null;

        this.brushMode = false;
        this.brushing = false;

        this.vis = null;
        this.zoomer = null;
        this.svg_graph = null;
        this.nodeGraph = this.configurations.graphdata;
        this.maxDegree = Math.max.apply(null, this.nodeGraph.links.map(d => d.degree));

        this.nodeGraph.links.map(d => {
            this.linksMap[d.id] = d;
        });

        this.globalSVG;
        this.logos = {
            shoulders: "M 7.74328 7.08732C 7.6017 7.08876 3.42293 7.12288 0.304244 6.01966L 0.00501061 5.91379L 0.000257865 5.61199C 0.000142519 5.60393 -0.0611522 2.80449 1.7856 1.89232L 5.08198 0.176297L 5.42074 0L 5.66795 0.28339C 5.74613 0.373007 5.83287 0.454724 5.92658 0.528477C 6.40698 0.906554 7.08076 1.0978 7.76092 1.10074C 8.44089 1.10366 9.11577 0.918461 9.59851 0.543712C 9.694 0.469589 9.7812 0.388808 9.85841 0.301475L 10.1063 0.0210889L 10.4425 0.196102L 13.7011 1.89197C 15.5478 2.80414 15.4863 5.60394 15.4862 5.61198L 15.4815 5.91378L 15.1822 6.01966C 12.0636 7.12288 7.88485 7.08875 7.74328 7.08732Z",
            head: "M 0.352824 3.67686C 0.333584 3.5008 0.325163 3.32862 0.327124 3.16063C 0.337367 2.28004 0.638538 1.56152 1.16881 1.02862C 1.69353 0.501297 2.43346 0.167243 3.32843 0.0487475C 3.58545 0.0147329 3.85868 -0.00115337 4.14657 0.00165395L 4.15166 0.00161046L 4.15169 0C 4.16253 0.000108811 4.17328 0.000587141 4.18394 0.00139235C 4.45814 0.000260712 4.71887 0.0162127 4.9647 0.0487475C 5.8597 0.167222 6.59961 0.501296 7.12434 1.02862C 7.65464 1.56154 7.95579 2.28004 7.96603 3.16063C 7.96799 3.32862 7.95957 3.5008 7.94033 3.67686C 8.89038 5.01912 7.65824 6.47152 7.31831 6.82983C 7.00343 7.7805 6.45251 8.46645 5.79875 8.88481C 5.28737 9.21209 4.71698 9.37575 4.14658 9.37575C 3.57617 9.37575 3.00583 9.21207 2.4944 8.88479C 1.84061 8.46641 1.28971 7.78048 0.974837 6.82983C 0.63491 6.47152 -0.597215 5.01912 0.352824 3.67686Z",
            // diagram: "M479.755,278.716c-10.683-39.866-36.25-73.187-71.993-93.823c-3.665-2.116-7.416-4.057-11.225-5.859   c0.341-4.182,0.523-8.409,0.523-12.678c0-85.201-69.315-154.517-154.517-154.517S88.027,81.155,88.027,166.356   c0,4.269,0.182,8.495,0.523,12.678c-3.809,1.802-7.56,3.743-11.225,5.859c-35.743,20.636-61.311,53.957-71.993,93.823   c-10.682,39.867-5.2,81.507,15.437,117.25c27.521,47.669,78.847,77.281,133.945,77.281c26.975,0,53.645-7.167,77.128-20.725   c3.691-2.131,7.256-4.398,10.702-6.781c3.447,2.383,7.011,4.65,10.702,6.781c23.483,13.558,50.153,20.725,77.128,20.725   c55.099,0,106.424-29.612,133.945-77.281C484.955,360.223,490.437,318.583,479.755,278.716z M118.027,166.356   c0-68.659,55.858-124.517,124.517-124.517S367.06,97.697,367.06,166.356c0,0.741-0.015,1.479-0.028,2.217   c-11.889-2.901-24.11-4.405-36.398-4.405c-31.935,0-62.591,9.965-88.091,27.61c-25.5-17.646-56.156-27.61-88.091-27.61   c-12.288,0-24.509,1.503-36.398,4.405C118.042,167.834,118.027,167.097,118.027,166.356z M242.543,406.848   c-24.136-24.098-37.042-56.962-36.507-90.344c11.71,2.847,23.933,4.368,36.507,4.368s24.797-1.521,36.507-4.368   C279.585,349.885,266.679,382.75,242.543,406.848z M242.543,290.872c-11.187,0-22.03-1.492-32.35-4.271   c2.753-10.328,6.883-20.464,12.476-30.151c5.519-9.559,12.228-18.216,19.874-25.829c7.646,7.614,14.355,16.27,19.874,25.829   c5.593,9.688,9.723,19.824,12.476,30.151C264.573,289.381,253.73,290.872,242.543,290.872z M182.218,275.249   c-29.179-16.229-51.188-43.84-59.989-76.795c10.487-2.83,21.325-4.287,32.223-4.287c22.994,0,45.164,6.41,64.286,17.911   c-8.405,8.786-15.838,18.613-22.049,29.371C190.402,252.339,185.607,263.685,182.218,275.249z M288.398,241.45   c-6.211-10.758-13.644-20.585-22.049-29.371c19.122-11.5,41.292-17.911,64.286-17.911c10.897,0,21.736,1.456,32.223,4.287   c-8.8,32.954-30.81,60.566-59.989,76.795C299.479,263.685,294.685,252.339,288.398,241.45z M154.713,443.247   c-44.415,0-85.785-23.865-107.965-62.281c-16.63-28.804-21.047-62.359-12.439-94.485c8.608-32.126,29.212-58.978,58.016-75.607   c0.638-0.368,1.286-0.716,1.929-1.072c12.482,42.532,42.801,77.508,82.272,96.238c-3.515,43.551,11.617,87.298,42.214,119.374   c-0.63,0.379-1.259,0.76-1.899,1.129C197.912,437.471,176.429,443.247,154.713,443.247z M438.338,380.966   c-22.18,38.417-63.55,62.281-107.965,62.281c-21.716,0-43.199-5.776-62.128-16.705c-0.64-0.369-1.269-0.75-1.899-1.129   c30.597-32.076,45.729-75.823,42.214-119.374c39.472-18.73,69.791-53.705,82.272-96.238c0.644,0.357,1.292,0.704,1.929,1.072   c28.804,16.63,49.407,43.481,58.016,75.607C459.385,318.607,454.968,352.162,438.338,380.966z"
            diagram: "M267.383,305.082c-12.771,3.209-26.13,4.923-39.883,4.923c-13.751,0-27.108-1.713-39.878-4.921   c-0.925,36.595,13.21,72.719,39.883,98.954C254.175,377.802,268.308,341.675,267.383,305.082z M98.038,179.771c9.377,36.233,33.598,66.552,65.763,84.054c3.607-12.663,8.802-25.088,15.677-36.996   c6.826-11.824,14.963-22.596,24.211-32.166c-10.849-6.635-22.714-11.752-35.341-15.135   C144.927,173.252,120.798,173.426,98.038,179.771z M176.112,150.549c18.673,5.003,35.987,13.094,51.388,23.831c15.4-10.737,32.715-18.827,51.388-23.831   c27.372-7.335,55.531-7.464,82.271-0.702c0.031-1.183,0.056-2.367,0.056-3.558c0-73.849-59.866-133.715-133.715-133.715   c-73.849,0-133.715,59.866-133.715,133.715c0,1.192,0.026,2.378,0.057,3.562C120.581,143.089,148.74,143.215,176.112,150.549z M388.119,192.883c-1.05-0.606-2.107-1.187-3.166-1.761c-13.068,45.826-45.634,83.511-88.128,103.457   c3.973,46.774-12.381,93.818-45.534,128.048c1.027,0.63,2.06,1.256,3.11,1.862c63.956,36.925,145.737,15.012,182.662-48.944   C473.988,311.589,452.075,229.808,388.119,192.883z M263.193,275.161c-2.954-11.421-7.473-22.631-13.652-33.333c-6.126-10.611-13.545-20.186-22.041-28.56   c-8.496,8.374-15.915,17.948-22.041,28.56c-6.178,10.701-10.696,21.911-13.65,33.331c11.367,3.152,23.334,4.845,35.691,4.845   C239.857,280.004,251.826,278.314,263.193,275.161z M158.175,294.579c-42.494-19.946-75.057-57.632-88.125-103.459c-1.06,0.575-2.118,1.157-3.169,1.763   C2.925,229.808-18.988,311.589,17.937,375.545s118.706,85.869,182.662,48.944c1.05-0.606,2.081-1.231,3.108-1.861   C170.553,388.398,154.201,341.352,158.175,294.579z M291.201,263.831c32.165-17.502,56.386-47.823,65.764-84.055c-22.76-6.346-46.89-6.525-70.313-0.248   c-12.627,3.384-24.492,8.5-35.341,15.135c9.248,9.57,17.385,20.342,24.211,32.166C282.398,238.739,287.594,251.166,291.201,263.831   z",

            threeGuys: ["M 0.352824 3.67686C 0.333584 3.5008 0.325163 3.32862 0.327124 3.16063C 0.337367 2.28004 0.638538 1.56152 1.16881 1.02862C 1.69353 0.501298 2.43346 0.167244 3.32843 0.0487477C 3.58545 0.0147332 3.85868 -0.00115312 4.14657 0.0016542L 4.15166 0.00161071L 4.15169 2.4925e-07C 4.16253 0.000109061 4.17328 0.00058739 4.18394 0.0013926C 4.45814 0.000260961 4.71887 0.016213 4.9647 0.0487477C 5.8597 0.167222 6.5996 0.501296 7.12434 1.02862C 7.65464 1.56154 7.95579 2.28004 7.96603 3.16063C 7.96799 3.32862 7.95957 3.5008 7.94033 3.67686C 8.89038 5.01912 7.65824 6.47152 7.31831 6.82983C 7.00343 7.7805 6.45251 8.46645 5.79875 8.88481C 5.28737 9.21209 4.71698 9.37575 4.14658 9.37575C 3.57617 9.37575 3.00583 9.21207 2.4944 8.88479C 1.84061 8.46641 1.28971 7.78048 0.974837 6.82983C 0.634909 6.47152 -0.597227 5.01912 0.352813 3.67686L 0.352824 3.67686ZM 1.26102 3.16755C 1.25906 3.33586 1.27129 3.51573 1.29841 3.70702C 1.32534 3.83091 1.29608 3.96478 1.20607 4.07145L 1.20535 4.07093C 0.451839 4.96434 1.53375 6.10564 1.70215 6.27365C 1.76605 6.32718 1.81522 6.3978 1.84075 6.48096L 1.83916 6.48139C 2.08282 7.27478 2.51219 7.83205 3.01813 8.15583C 3.3676 8.37946 3.75715 8.49132 4.14659 8.49132C 4.53603 8.49132 4.9256 8.37948 5.27503 8.15585C 5.77363 7.83677 6.19792 7.29082 6.44334 6.51556C 6.4608 6.43443 6.50255 6.35698 6.56874 6.29363L 6.56969 6.29452C 6.58438 6.28057 7.88437 5.04545 7.10014 4.08625C 7.01428 3.993 6.97003 3.86652 6.98964 3.73461L 6.99073 3.73477C 7.02067 3.5331 7.03419 3.34396 7.03214 3.16755C 7.02464 2.5223 6.8139 2.0058 6.44315 1.63322C 6.0668 1.25501 5.51629 1.0128 4.83653 0.92281C 4.62973 0.895433 4.41417 0.881853 4.19111 0.882419C 4.17478 0.883877 4.15822 0.884552 4.14145 0.884377L 4.14147 0.882658C 3.90436 0.880286 3.67558 0.893822 3.45661 0.92281C 2.77687 1.01282 2.22634 1.25501 1.85001 1.63322C 1.47928 2.00581 1.26852 2.5223 1.26102 3.16755L 1.26102 3.16755Z",
                "M 7.74328 7.08732C 7.6017 7.08876 3.42293 7.12288 0.304243 6.01966L 0.00501036 5.91379L 0.000257609 5.61199C 0.000142263 5.60393 -0.0611525 2.80449 1.7856 1.89232L 1.78539 1.89198L 5.08198 0.176296L 5.42074 -5.7904e-07L 5.66795 0.283389C 5.74613 0.373007 5.83287 0.454724 5.92658 0.528476C 6.40698 0.906553 7.08076 1.0978 7.76092 1.10074C 8.44089 1.10366 9.11576 0.91846 9.59851 0.543711C 9.694 0.469589 9.7812 0.388807 9.85841 0.301475L 10.1063 0.0210883L 10.4425 0.196102L 13.7011 1.89197L 13.7009 1.89232C 15.5476 2.80449 15.4863 5.60393 15.4862 5.61198L 15.4815 5.91378L 15.1822 6.01966C 12.0636 7.12288 7.88482 7.08875 7.74325 7.08732L 7.74328 7.08732ZM 0.94306 5.2993C 3.91151 6.25358 7.72816 6.20638 7.73959 6.20629L 7.74692 6.20629C 7.75834 6.20638 11.575 6.25358 14.5434 5.2993C 14.5043 4.65794 14.3006 3.17791 13.2617 2.67102L 13.2507 2.66584L 10.3043 1.13243C 10.2676 1.164 10.2301 1.19462 10.1918 1.22431C 9.53568 1.7337 8.64298 1.98553 7.75731 1.98173C 6.87176 1.9779 5.98138 1.71853 5.32967 1.20564C 5.29172 1.17578 5.25458 1.14511 5.21836 1.11365L 2.23588 2.66585L 2.22489 2.67103C 1.18601 3.17791 0.982238 4.65795 0.943089 5.2993L 0.94306 5.2993Z",
                "M 0.253574 2.76138C 0.242317 2.64421 0.237473 2.52898 0.238788 2.41586C 0.246609 1.74399 0.47774 1.19445 0.884776 0.785446C 1.28621 0.382016 1.84956 0.12679 2.52912 0.0368223C 2.72078 0.0114692 2.92517 -0.000391889 3.14099 0.0016755L 3.14611 0.00163201L 3.14613 4.62787e-07C 3.1572 0.000109274 3.16818 0.000609991 3.17905 0.00143696C 3.38086 0.00104524 3.5725 0.0129491 3.75286 0.0368223C 4.43241 0.126788 4.99576 0.382016 5.3972 0.785446C 5.80423 1.19445 6.03536 1.74399 6.04319 2.41586C 6.0445 2.52898 6.03966 2.64421 6.0284 2.76138C 6.7071 3.77213 5.83955 4.84001 5.55861 5.14279C 5.31931 5.84833 4.90467 6.35978 4.41273 6.67458C 4.0191 6.92648 3.58005 7.05244 3.14097 7.05244C 2.70186 7.05244 2.26281 6.92646 1.8692 6.67453C 1.37729 6.35974 0.962595 5.84826 0.723364 5.14279C 0.442402 4.84003 -0.425146 3.77218 0.25358 2.76138L 0.253574 2.76138ZM 1.17268 2.42278C 1.17137 2.53647 1.17958 2.65888 1.19783 2.78991C 1.22454 2.91367 1.19524 3.04727 1.10537 3.1538L 1.10465 3.15328C 0.631659 3.71422 1.32077 4.45656 1.45145 4.58835C 1.51496 4.64182 1.56385 4.71222 1.58927 4.79503L 1.58765 4.79546C 1.75578 5.34292 2.04886 5.72539 2.39291 5.94558C 2.62458 6.09385 2.88284 6.16802 3.14096 6.16802C 3.39911 6.16802 3.65735 6.09387 3.88901 5.94563C 4.22603 5.72994 4.51412 5.35852 4.68382 4.82885C 4.7014 4.74792 4.74318 4.67072 4.80925 4.60753L 4.81019 4.60842C 4.82989 4.58966 5.67795 3.77734 5.18936 3.16828C 5.10368 3.07507 5.05957 2.94872 5.07916 2.81697L 5.08022 2.81712C 5.10119 2.6758 5.11069 2.54431 5.10929 2.42279C 5.10421 1.9863 4.96351 1.63875 4.716 1.39005C 4.46295 1.13574 4.08897 0.972368 3.62468 0.91089C 3.4831 0.892152 3.3362 0.882598 3.18486 0.882489C 3.16874 0.883882 3.15238 0.884557 3.13584 0.884383L 3.13586 0.882663C 2.97082 0.881053 2.81091 0.890564 2.65729 0.91089C 2.19299 0.972368 1.81901 1.13574 1.56597 1.39005C 1.31845 1.63875 1.17775 1.9863 1.17268 2.42279L 1.17268 2.42278Z",
                "M 0.157548 1.21599C -0.0356126 1.3772 -0.0536524 1.65563 0.117246 1.83785C 0.288144 2.02006 0.583295 2.03708 0.776455 1.87586C 1.03084 1.66303 1.68894 1.34317 2.2158 1.08713C 2.29777 1.04728 2.37685 1.00885 2.45072 0.972662C 3.18896 1.52053 4.0665 1.79569 4.94637 1.79804C 5.82527 1.80041 6.70347 1.52971 7.44403 0.986132C 7.54618 1.03714 7.65449 1.09068 7.76061 1.1431C 8.87426 1.69343 9.67806 2.09086 9.75023 3.45496C 8.86671 3.73202 7.85734 3.90707 6.82154 3.99865C 5.49138 4.11627 4.12025 4.09582 2.91421 3.97673C 2.65735 3.95195 2.42777 4.12827 2.40149 4.37057C 2.37521 4.61287 2.56212 4.82945 2.81898 4.85423C 4.07711 4.97848 5.51088 4.9995 6.90579 4.87615C 8.12695 4.76819 9.32035 4.54919 10.3453 4.1917C 10.5406 4.14134 10.6859 3.97471 10.6902 3.77412L 10.2215 3.76512L 10.6885 3.77376C 10.7351 1.61867 9.68619 1.10034 8.19274 0.362315C 8.03354 0.283666 7.86781 0.201731 7.63714 0.0819942C 7.4629 -0.0224869 7.22953 -0.00879888 7.06975 0.128804L 7.0703 0.129371C 6.45804 0.656477 5.70104 0.919082 4.94637 0.917059C 4.20212 0.915078 3.45615 0.654649 2.84998 0.135921C 2.70653 -0.00516412 2.47542 -0.0438138 2.28538 0.0550961L 2.28577 0.0557919C 2.14417 0.129458 1.97397 0.212154 1.78731 0.302903C 1.21611 0.580482 0.502645 0.927244 0.157548 1.21599L 0.157548 1.21599Z",
                "M 0.253575 2.76138C 0.242317 2.64421 0.237473 2.52898 0.238788 2.41586C 0.246609 1.74399 0.47774 1.19445 0.884777 0.785446C 1.28621 0.382016 1.84956 0.12679 2.52912 0.0368223C 2.72078 0.0114692 2.92517 -0.000391889 3.14099 0.0016755L 3.14611 0.00163201L 3.14613 4.62787e-07C 3.1572 0.000109274 3.16818 0.000609991 3.17905 0.00143696C 3.38086 0.00104524 3.5725 0.0129491 3.75286 0.0368223C 4.43241 0.126788 4.99577 0.382016 5.3972 0.785446C 5.80423 1.19445 6.03536 1.74399 6.04319 2.41586C 6.0445 2.52898 6.03966 2.64421 6.0284 2.76138C 6.7071 3.77213 5.83955 4.84001 5.55861 5.14279C 5.31931 5.84833 4.90467 6.35978 4.41273 6.67458C 4.0191 6.92648 3.58004 7.05244 3.14096 7.05244C 2.70186 7.05244 2.26281 6.92646 1.8692 6.67453C 1.37729 6.35974 0.962595 5.84826 0.723364 5.14279C 0.442402 4.84003 -0.425146 3.77218 0.253579 2.76138L 0.253575 2.76138ZM 1.17268 2.42278C 1.17137 2.53647 1.17958 2.65888 1.19783 2.78991C 1.22454 2.91367 1.19524 3.04727 1.10537 3.1538L 1.10465 3.15328C 0.631658 3.71422 1.32076 4.45656 1.45145 4.58835C 1.51496 4.64182 1.56385 4.71222 1.58927 4.79503L 1.58765 4.79546C 1.75578 5.34292 2.04886 5.72539 2.39291 5.94558C 2.62458 6.09385 2.88284 6.16802 3.14096 6.16802C 3.39911 6.16802 3.65735 6.09387 3.88901 5.94563C 4.22603 5.72994 4.51412 5.35852 4.68382 4.82885C 4.7014 4.74792 4.74318 4.67072 4.80925 4.60753L 4.81019 4.60842C 4.82989 4.58966 5.67795 3.77734 5.18936 3.16828C 5.10368 3.07507 5.05957 2.94872 5.07916 2.81697L 5.08022 2.81712C 5.10119 2.6758 5.11069 2.54431 5.10929 2.42279C 5.10421 1.9863 4.96351 1.63875 4.716 1.39005C 4.46295 1.13574 4.08897 0.972368 3.62468 0.91089C 3.4831 0.892152 3.3362 0.882598 3.18486 0.882489C 3.16873 0.883882 3.15238 0.884557 3.13584 0.884383L 3.13586 0.882663C 2.97082 0.881053 2.81091 0.890564 2.65729 0.91089C 2.19299 0.972368 1.81901 1.13574 1.56597 1.39005C 1.31845 1.63875 1.17775 1.9863 1.17268 2.42279L 1.17268 2.42278Z",
                "M 7.85464 4.85585C 8.11149 4.83106 8.2984 4.61448 8.27213 4.37218C 8.24585 4.12988 8.01626 3.95356 7.75941 3.97834C 6.55634 4.09617 5.1891 4.11577 3.86261 3.99793C 2.82855 3.90607 1.82136 3.73119 0.940205 3.45494C 1.01313 2.0877 1.82487 1.68712 2.94256 1.13584C 3.0523 1.08174 3.16425 1.0265 3.27007 0.973728C 4.00799 1.52088 4.88495 1.79567 5.76425 1.79802C 6.64377 1.80039 7.52255 1.52932 8.26343 0.984977C 8.33476 1.01993 8.41098 1.05699 8.49002 1.0954C 9.01252 1.34939 9.6678 1.66795 9.91743 1.8786C 10.1096 2.04078 10.4047 2.02533 10.5766 1.84407C 10.7486 1.66281 10.7322 1.38438 10.54 1.22221C 10.1968 0.932595 9.48562 0.586835 8.91851 0.311171C 8.74629 0.227474 8.58843 0.150718 8.4546 0.0817095C 8.28041 -0.0225102 8.04729 -0.00871405 7.88763 0.128781L 7.88818 0.129347C 7.27592 0.656453 6.51892 0.919058 5.76425 0.917035C 5.01993 0.915055 4.27389 0.654603 3.66768 0.135743C 3.52423 -0.00516799 3.29324 -0.0437749 3.10328 0.0550697L 3.10368 0.0557444C 2.85773 0.183729 2.68024 0.2713 2.51042 0.355041C 1.02348 1.08843 -0.0307391 1.60886 0.00132483 3.73191C -0.0139932 3.92296 0.104537 4.10851 0.304272 4.17915L 0.468849 3.76509L 0.305887 4.17795C 1.33785 4.54297 2.54247 4.76594 3.77472 4.87543C 5.16691 4.99913 6.59805 4.97891 7.85464 4.85584L 7.85464 4.85585Z"
            ]
        };

        this.vertexDegree = 1;
        this.linkDegree = 0;
        this.sliderCounter = 0;

        this.graphState = {
            selected: 0,
            nodes: this.nodeGraph.nodes.length,
            results: 0
        };

        this.onChange = (state) => {
            if (this.configurations.onChange instanceof Function) {
                this.configurations.onChange(state);
            }
        };

        this.customArrangement = (graph) => {
            if (this.configurations.customArrangement instanceof Function) {
                this.configurations.customArrangement(graph);
            }
        };

        this.getColor = (v) => {
            if (!(this.configurations.getColor instanceof Function)) {
                if (v.component){
                    return this.color(v.component);
                }
                return this.color(1);
            }
            else {
                return this.configurations.getColor(v);
            }
        };

        this.getLineColor = (v) => {
            if (!(this.configurations.getLineColor instanceof Function)) {
                return this.lineColor;
            }
            else {
                return this.configurations.getLineColor(v);
            }
        };

        this.getPicture = (v) => {
            if (!(this.configurations.getPicture instanceof Function)) {
                // return "https://cdn3.iconfinder.com/data/icons/complete-set-icons/512/photo512x512.png";
                // return "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxASEhAPEBIPEBASEA4QEhAXFQ8QEBASFhIWFxUSFRcYHSggGBolGxUVITEhJikrLi4uFx8zODMsNygyLi0BCgoKDg0OFxAPFislHh0tLS0tLS0rKy0rLS0tKystKy0tKystKy0rLS0tLS0rLS0tKystLS0tLS0tLSsrKy0tLf/AABEIAOcA2gMBIgACEQEDEQH/xAAbAAEAAwEBAQEAAAAAAAAAAAAAAgMEBQEGB//EAD4QAAIBAgIFBwgJBAMAAAAAAAABAgMRBCEFEjFBURMVUmFxkaEiMnKBkpOxwQYUQlNUYqLh8CMzstFDc/H/xAAXAQEBAQEAAAAAAAAAAAAAAAAAAQID/8QAIBEBAQEAAgICAwEAAAAAAAAAAAERAjEhUTJBImFxA//aAAwDAQACEQMRAD8A/cQAAAAAAAAAAAAA5+lNI8mlGC1qs3aMdy4yfUjZXnZdpwaHlVq039nVpx6lv8fiWRjlyzo+pyl5VSrVlPqlqxXYi3D4+pRajWbqUm7Kr9qHVLius0EZRTTTSaeTW5mmOunWjJNJrNPNPc0enz+FxDwz1ZXlh5PJ7XSb3ej/ADt7sasWk07p5p7UzNjpOWpg8TR6RoAAAAAAAAAAAAAAAAAAAAAAyudTgVOTZcTVsqq3ZkHUZABNVYnc+05OHkliKkE1aUYya362Wz1O51q73HAwGDdedepGWrKLTpvde7tfqsres1HPl34dkGXCYrWvCa1KscpQfxXFGoIjKKaaaTTya3MxT0ZRSbd4pXd9Z+SbpSSV20ktreSRjjCWJepC8aCfl1Nmu19mP8/cdpaMxMozVKUnOEo61Kb2tb4s7Cmz5nDy8jCy+1GvqP1t3XdY+kFa4XwtjV4likmZgmZxvWoFUavEsTI09AAAAAAAAAAAA8bsAbKZ1L9h5OVyJWbQAFAAAYdJVdWM5cIO3bbI8+itK1Fy6U5P1Ky+KZk07UtTl+aSXjf5HZ0TS1aNKP5It9rzfixemePnk8x+joVbOV4zXmzjlKPr4GHmzErJV4tcXBax2gTWrxlcmnoOLadac61vsvyYdyOpCCSSSSSySWSSJAmrJJ0+Rqq03DhjYv1Su18D6Q+f0wtXEv8ANPD1O7yT6A3XPj3QAEbCUZWIgDRGVyRmTL4TuRZUgARQAAAAAbM85XJVZbissSgAKgAAB42ekauxhHA07nyUOlJ/JfM+qSPlNJO9egvzU/Gp+x9YOScO6AAy6AAA+Y+lUbVaU+MbezK/zO6zj/TCOVJ8HUXel/o68HdJ8Un4Gvpznyr0ABoAAA9TPABohK5IzwlY0IysAAFCNSVkSKKsrsJUAAaQAAAAACFbY/USnNJXbstpzKTxNaLqwdOMG3qU2s5JPa3uYS1zdJS/rxl0OSf6/wBz7A+Ro4GpiZ1nlTaUIyjK7a6u+PifWx7xyT/P7egAy6AAA4P0u/t0/Tf+LN2ClenTfGnB/pRm+k+HcqSmmrU3drje0fmZ8BSxcqUHFwpxjFKCavKdltfBM19Od+VdcGbR+K5SCk1qyTcZR4SW1GkKAAKAAAW0Zbio9TINIPEz0jSM3ZGctrPYiosZoACgAAAAAy4uN9aPGLXejzQGJTpqk7KpTvGUd9k8muKsaKlO/aYcXo+nJpzim+Kun4BnzLq/QucsVLjiJx9n/wBOocj6MxSpzS++qfBI65L21x6AZMfjlS1XKM3BtpzSuocNYspYylJXjODXpIi7F4MGL0tShkpKpN5Rpx8qTfDLYX4GVRwTqqMZu71VfJbk+sGqtNRvQreg33Zili4woU6k2kuSg+t+SslxZPSi/o1v+qp/izlaM0ZR1KdRwvJwjLNtq9uGws6Ztu+F+hoSVNykrOpOdW3DW2fA3AFJMAAFAAAAAF1F7iwopvMvM1YoqvMgey2vtPCoAAoAAAAABTiFsLjyUb5BK5+h6yp1alGWSnJ1ab4386Ph4M7ZxMbg1JWldNO8ZLbF8UeUNK1KXk4hOUdirRV/aQsTjyzxXcZhq6Iw8s3Sh6vJ+Bow+JhUV4SjJdT2dq3FxlvxWfDYKlT8yEYviln37TQRqVIxV5NRXFtJHKr6aUnyeHjys+lspx6295ey2RZp7EWhyMc6lXyIx6n5zfVYuo01GMYLZGMY9ysZsFgnFupUlylaW2W6K6MVuRsKz+wABQAAAAAAABGoyl0Z5IlWKWACoAAAAAAAAAjVqRinKTUUt7yRgWNqVcsPC62ctO8YLsW1/wAyCa24itCC1ptRj17+zicPHY2NSPJwjOLqOEYNqymnLNo6+G0PFPXrN1qnGXmrsjsNWOwUKsdWS2ZxkspRfFMal42xhq6Dpt3S1Gtkotxf+hHRVXZ9ZrJdus+8Rq4qjlOH1iC2TjlUt1x3v+XJc+U99OunwcHf4jyfilDQdK+tUdStLjOTl4GTSco0a9KUY3TpThycEr2Tuml/NhoekK9TKjRlH89XyEuvV3mjAaOUG6k5OpWl503u6orch/TJekMJjKdRXhJPitkl2ovK8boqnUetZwqbVUj5Mr9fExyliKPnx5emvtxVqiXXHf8AzML5nboAowuLp1FeEk+K2SXai8CitNqVPPJuSa45ZF5XWpa2rnbVkpfsWAAZnWlJ2p7N83s9XE0gAAFD254APZHhKos2RAAAAUVMSld7km2+ovOVpJf0qnosRm3COkqs/Kp0U4bnKSi312EsZid1Kmnx10/mW4V+RD0IfBFpWdvtyY0q7lr1aarPcpTioR7IrI6K0liFkqELenEtAJsVc54n7iPvIjnPE/cR95EtAyG32q50xH4ePvIjnTEfh4+8iWgZDb7Vc6Yj8PH3kRzpifw8feRLQMht9quc8T9xH3kRznifuIe8iWgZDb7czGQq1HrqhGnU2qpGooyv18S6hisWlaVOE30taMX67M2gIzfXsQs3Qi1wU1c24PFRqx1o3WbUovbF70ysz6I8/EvdykV67O4aluulFJZLJcD0hysb2ur8Lq5MjQAAoTUCBpSIRVWRWX1VkUAoACgc7GxvCovyT+DOiYq8b6y46yEZ5KdHu9Kn6EV3KxoMeiHejDskv1M2FYgAAoAAACResM+KBJqgEpwayZEAAAAAAFGhP+eXGvPwt/svKdAf2m+lUqPxt8gTtunRjLbFPr3957TgoqyyRIEbAAFewWaNJTRW8uJVgZpK2RpK60d4hVIAKgZam19pqM1bb3CM1z9Df27cJzXibjDor/lXCtU+RuNMQABFAABbhvO7zWc9MvWJfBEsa43EsXsXaZiU5t5siWJbtAAEAABGbsm+CbI6CjahT69d/rZHFu0Kj4Qn8GX6KjajS9CL78/mKce2oAEdAAnSjdkFsI2RIAjQAAM842ImicbmdlZoZ6+31GgqrQbzRUrl4Dz8Qvzp96ZuOdOfI1ZupeMKig4ys7XirNMu5xo9OPiac2sGTnGj04+I5xo9OPiQ1rBk5xo9OPiOcaPTj4g1rBk5xo9OPiOcaPTj4g1rBk5xo9OPiOcaPTj4g1rBk5xo9OPiOcaPTj4g1rBk5xo9OPiOcaPTj4g1LSTtSqei135G7BxtTprhTgv0o4+NxUaseRpPXnNpZXsldNt9R3YqyS4JIVrj29ABGw0QjZEaUN5YSrAAEUAAAhUhftJgDKC+cL9pS0VlGSTydmuG1EOQh0IezEsBUV8hDoQ9mI5CHQh7MSwAV8hDoQ9mI5CHQh7MSwAV8hDoQ9mI5CHQh7MSwAV8hDoQ9mI5CHQh7MSwAV8hDoQ9mI5CHQh7MSwAV8hDoQ9mI5CHQh7MSwARhBLYkuxJEgAoWU4b2e06e99xaRZAAEUAAAAAAAAIyimSAGeUGiJqISprsLqYoBKUGiJUAAAAAAAAAAAB6otlkaXEgrjG5dCnbtJJHpFwAAUAAAAAAAAAAAAAAAAIuCYAEXSIukwAmI8mxqMAphqM9VJnoGmPVS6ySpoAi4mAAAAAAAAAAAAA/9k="
                return "http://webcomme.ru/components/com_community/assets/user.png"
            }
            else {
                return this.configurations.getPicture(v);
            }
        };

        this.processVisibleNodes = (nodes) => {
            if (this.configurations.processVisibleNodes instanceof Function) {
                this.configurations.processVisibleNodes(nodes);
            }
        };

        this.specialView = (node) => {
            if (this.configurations.specialView instanceof Function) {
                return this.configurations.specialView(node);
            }
            return false;
        };

        if (this.configurations.showDegree === undefined) {
            this.configurations.showDegree = false;
        }

        this.tick = (function() {
            if (this.configurations.currentIconAppearance === "picture"){
                this.tickCircular();
            } else {
                this.tickCentral();
            }

        }).bind(this);
    }

    arrangeInternal (mode, self) {
        if (self.svg_graph === null) {
            self.initSVG();
        }

        if (self.nodeGraph === null){
            return;
        }

        // self.zoomer.scale(1);

        switch (mode) {
            // case 'linear':
            //     self.rearrange(self.nodeGraph, 'linear', self.fontSize);
            //     break;
            //
            // case 'circular':
            //     self.rearrange(self.nodeGraph, 'circular', self.fontSize);
            //     break;
            // case 'tree':
            //     self.rearrange(self.nodeGraph, 'tree', self.fontSize);
            //     break;
            case 'custom':
                self.customArrangement(self.nodeGraph);
                break;
            case 'force':
                for (let i = 0; i < self.nodeGraph.nodes.length; i += 1 ) {
                    self.nodeGraph.nodes[i].fixed = false;
                }
                break;
        }

        self.initForce(self.nodeGraph);
    }

    arrange (key) {
        if (this.configurations.graphdata){
            this.removeSVG(key, this.arrangeInternal);
            // this.centerView();
            this.visibilityChange('neighbour', this.configurations.min_neighbor);
            this.visibilityChange('substring', this.configurations.substring);
            this.visibilityChange('degree', this.configurations.minNodeDegree);
        }
    }

    initSVG () {
        this.svg_graph = d3.select('#' + this.configurations.graphId)
            .attr("viewBox", "0 0 " + this.width + " " + (this.height - 200))
            .append("svg")
            .style('outline', 'none')
            .attr('id', this.configurations.svgId)
            .attr("xmlns","http://www.w3.org/2000/svg")
            .attr('xmlns:xlink', "http://www.w3.org/1999/xlink")
            // .attr("viewBox", "-50 0 " + (width+width/2) + " " + (height))
            // .attr("preserveAspectRatio", "xMidYMid meet")
            .attr("tabindex", 1)
            // .attr('class','brush')
            .attr("width", this.width)
            .attr("height", this.height);

        // для корректного формирования строки svg для печати
        this.svg_graph.append('style')
            .attr('id', 'graph_style')
            .attr('type', 'text/css')
            .text('.node { stroke: rgb(135, 135, 135); stroke-width: 0; } .brush .background {background-color: rgba(255,255,255,0.0);opacity: 0.0;} .background {opacity: 0;}');

        this.svgDefs = this.svg_graph.append("defs");

        this.svgDefs
            .append("marker")
            .attr("id", "point")
            .attr("viewBox", "-2 -2 4 4")
            .attr("refX", "0")
            .attr("refY", "0")
            .attr("markerUtils", "strokeWidth")
            .attr("markerWidth", "4")
            .attr("markerHeight", "4")
            .append("circle")
            .attr("cx", "0")
            .attr("cy", "0")
            .attr("r", "2")
            .attr("fill", this.lineColor);

        this.svgDefs.append("rect")
            .attr("id", "rect")
            .attr("x", -this.imgR)
            .attr("y", -this.imgR)
            .attr("width",this.imgR*2)
            .attr("height",this.imgR*2)
            .attr("rx", this.imgR);

        this.svgDefs.append("clipPath")
            .attr("id", "clip")
            .append("use")
            .attr("xlink:href", "#rect");

        this.zoomSquare = this.svg_graph.append("svg:g")
            .attr("class", "everything");

        this.rect = this.zoomSquare.append('rect')
            .attr('width', this.width)
            .attr('height', this.height)
            .style('fill', 'white');

        this.vis = this.zoomSquare.append("g")
            .attr('stroke', 'black')
            .attr('stroke-width', 1)
            .attr('opacity', 1)
            .attr('id', 'vis');
        // .attr("transform", "translate(" + this.width/2 + "," + this.height/2 + ")");


        this.gBrushHolder = this.vis.append('g');
        this.gBrush = null;

        d3.select('body').on('keydown', this.keydown.bind(this));
        d3.select('body').on('keyup', this.keyup.bind(this));

        if (this.configurations.brushable) {
            this.brush = d3.brush()
                .keyModifiers(false)
                .on("start", this.brushstarted.bind(this))
                .on("brush", this.brushed.bind(this))
                .on("end", this.brushended.bind(this));
        }

        this.rect.on('click', () => {
            this.node.each(function(d) {
                d.selected = false;
                d.previouslySelected = false;
            });
            this.node.classed("selected", false);
        });

        // this.brush.call(this.brusher)
        //     .on("mousedown.brush", null)
        //     .on("touchstart.brush", null)
        //     .on("touchmove.brush", null)
        //     .on("touchend.brush", null);
        //
        // this.brush.select('.background').style('cursor', 'auto');
    }

    initForce (graphLinksNodes) {
        this.simulation = d3.forceSimulation(graphLinksNodes.nodes)
            .force("center", d3.forceCenter(this.width / 2, this.height / 2))
            .force("charge", d3.forceManyBody().strength(-120))
            .force("link", d3.forceLink(graphLinksNodes.links).distance(60).strength(0.5).iterations(5))
            .force("collide", d3.forceCollide(60))
            .stop();

        d3.timeout(() => {
            // See https://github.com/d3/d3-force/blob/master/README.md#simulation_tick
            for (var i = 0, n = Math.ceil(Math.log(this.simulation.alphaMin()) / Math.log(1 - this.simulation.alphaDecay())); i < n; ++i) {
                this.simulation.tick();
            }

            graphLinksNodes.nodes.map(d => {d.fx = d.x; d.fy = d.y;});

            this.link = this.vis.append("g")
                .attr("class", "link")
                .selectAll("line")
                .data(graphLinksNodes.links)
                .enter().append("line")
                .attr("x1",d => {
                    if (this.configurations.currentIconAppearance === 'picture'){
                        let result = this.countLinkEnds(d.source.x, d.source.y, d.target.x, d.target.y);
                        return result.x1;
                    }
                    return d.source.x;
                })
                .attr("y1", d => {
                    if (this.configurations.currentIconAppearance === 'picture'){
                        let result = this.countLinkEnds(d.source.x, d.source.y, d.target.x, d.target.y);
                        return result.y1;
                    }
                    return d.source.y;
                })
                .attr("x2", d => {
                    if (this.configurations.currentIconAppearance === 'picture'){
                        let result = this.countLinkEnds(d.source.x, d.source.y, d.target.x, d.target.y);
                        return result.x2;
                    }
                    return d.target.x;
                })
                .attr("y2", d => {
                    if (this.configurations.currentIconAppearance === 'picture'){
                        let result = this.countLinkEnds(d.source.x, d.source.y, d.target.x, d.target.y);
                        return result.y2;
                    }
                    return d.target.y;
                })
                .attr("transform", () => {
                    if (this.configurations.currentIconAppearance === 'picture') {
                        return 'matrix(' + '1' + ',0,0,' + '1' + ',' + '0' + ',' + '-2.5' + ')'
                    }
                })
                .attr('id', function (d) {
                    return d.id;
                })
                .attr("stroke-dasharray", "")
                .style("stroke-width", function(d) { return 1 })
                .style("stroke", d => {
                    return this.getLineColor(d);
                })
                .on("click", d => {
                    if(this.configurations.onLinkClick  instanceof Function) {
                        this.configurations.onLinkClick(d, d3.event);
                    }
                });

            this.node = this.vis.append("g")
                .attr("class", "node")
                .selectAll(".node")
                .data(graphLinksNodes.nodes)
                .enter().append('g').attr("class", "node")
                .attr("id", d => d.id)
                .attr("x", d => d.x )
                .attr("y", d => d.y )
                .attr("transform", function(d) {
                    return "translate(" + d.x + "," + d.y + ")";
                })
                .on("click", d => {
                    if(this.configurations.onNodeClick  instanceof Function) {
                        this.configurations.onNodeClick(d, d3.event);
                    }
                })
                .on("mouseover", d =>{this.mouseover(d)})
                .on("mouseout", d =>{this.mouseout(d)});

            if (this.configurations.getNameList instanceof Function) {
                this.appendTextList(this.configurations.currentIconAppearance);
            } else {
                this.appendText(this.configurations.currentIconAppearance);
            }
            this.appendIcon(this.configurations.currentIconAppearance);
            this.lineDash(this.configurations.currentIconAppearance);
            this.appendLinkLabel(this.configurations.showDegree);
            this.appendBoxToNodes();

            var drag_handler = d3.drag()
                .on("start", this.dragStart.bind(this))
                .on("drag", this.dragDrag.bind(this))
                .on("end", this.dragEnd.bind(this));

            //same as using .call on the node variable as in https://bl.ocks.org/mbostock/4062045
            drag_handler(this.node);

            //add zoom capabilities
            this.zoom_handler = d3.zoom()
                .on("zoom", this.zoomActions.bind(this));

            this.zoom_handler(this.svg_graph);

            this.simulation.on("tick", this.tick );

            this.centerView();
        });
        this.simulation.tick();
    }

    dragStart(d) {
        if (!d3.event.active) this.simulation.alphaTarget(0.3	).restart();
        d.fx = d.x;
        d.fy = d.y;
    }

    dragDrag(d) {
        d.fx = d3.event.x;
        d.fy = d3.event.y;
    }

    dragEnd(d) {
        if (!d3.event.active) this.simulation.alphaTarget(0);
        d.fx = d.x;
        d.fy = d.y;
    }

    zoomActions() {
        this.vis.attr("transform", d3.event.transform);
    }

    tickCentral () {
        let transformMatrix = 'matrix(' + '1' + ',0,0,' + '1' + ',' + '0' + ',' + '0' + ')';
        this.link
            .attr("x1", (d) => {
                if (d.source.x)
                    return d.source.x;
            })
            .attr("y1", (d) => {
                if (d.source.y)
                    return d.source.y;
            })
            .attr("x2", (d) => {
                if (d.target.x)
                    return d.target.x;
            })
            .attr("y2", (d) => {
                if (d.target.y)
                    return d.target.y;
            }).attr("transform", transformMatrix);

        this.node
            .attr("transform", function(d) {
                if (d.x && d.y)
                    return "translate(" + d.x + "," + d.y + ")";
            });

        this.node
            .attr("x", d => d.x)
            .attr("y", d => d.y);

        if (this.edgelabels) {
            this.edgelabels
                .attr('dx', d => {
                    return (d.source.x + d.target.x)/2;
                })
                .attr('dy', d => {
                    return (d.source.y + d.target.y)/2;
                }).attr("transform", transformMatrix);
        }


    } ;

    tickCircular () {
        let transformMatrix = 'matrix(' + '1' + ',0,0,' + '1' + ',' + '0' + ',' + '-2.5' + ')';
        this.link

            .attr("x1", (d) => {
                let result = this.countLinkEnds(d.source.x, d.source.y, d.target.x, d.target.y);
                return result.x1;

                // return d.source.x;
            })
            .attr("y1", (d) => {
                let result = this.countLinkEnds(d.source.x, d.source.y, d.target.x, d.target.y);
                return result.y1;

                // return d.source.y;
            })
            .attr("x2", (d) => {
                let result = this.countLinkEnds(d.source.x, d.source.y, d.target.x, d.target.y);
                return result.x2;

                // return d.target.x;
            })
            .attr("y2", (d) => {
                let result = this.countLinkEnds(d.source.x, d.source.y, d.target.x, d.target.y);
                return result.y2;

                // return d.target.y;
            }).attr("transform", transformMatrix);

        //node
        //    .attr('cx', function(d) { return d.x; })
        //    .attr('cy', function(d) { return d.y; });

        this.node
            .attr("transform", function(d) {return "translate(" + d.x + "," + d.y + ")"; });

        if (this.edgelabels) {
            this.edgelabels
                .attr('dx', d => {
                    return (d.source.x + d.target.x)/2;
                })
                .attr('dy', d => {
                    return (d.source.y + d.target.y)/2;
                }).attr("transform", transformMatrix);
        }
    };

    countLinkEnds(x1, y1, x2, y2) {
        let r = this.imgR*1.15;
        let result = {};

        // предусмотреть случаи,
        // когда веришины приближаются друк к другу
        // на радиус и ближе

        if (x1 === x2) {
            result.x1 = x1;
            result.x2 = x1;
            if (y1 >= y2) {
                result.y1 = y1 - r;
                result.y2 = y2 + r;
            } else {
                result.y1 = y1 + r;
                result.y2 = y2 - r;
            }

        } else if (y1 === y2) {
            result.y1 = y1;
            result.y2 = y1;
            if (x1 >= x2) {
                result.x1 = x1 - r;
                result.x2 = x2 + r;
            } else {
                result.x1 = x1 + r;
                result.x2 = x2 - r;
            }
        } else {
            // let tan = (y2 - y1)/(x2 - x1);
            let cos = (y2 - y1)/Math.sqrt((y2 - y1)*(y2 - y1) + (x2 - x1)*(x2 - x1));
            let sin = (x2 - x1)/Math.sqrt((y2 - y1)*(y2 - y1) + (x2 - x1)*(x2 - x1));

            let x = Math.abs(r*sin);
            let y = Math.abs(r*cos);

            if (x1 >= x2) {
                result.x1 = x1 - x;
                result.x2 = x2 + x;
            } else {
                result.x1 = x1 + x;
                result.x2 = x2 - x;
            }

            if (y1 >= y2) {
                result.y1 = y1 - y;
                result.y2 = y2 + y;
            } else {
                result.y1 = y1 + y;
                result.y2 = y2 - y;
            }

        }

        return result;
    };

    translateVertex(x, y, id) {
        this.node.filter(d => d.staticId === id)
            .attr("transform", function(d) {
                d.x = x;
                d.y = y;
                d.cx = x;
                d.cy = y;
                d.px = x;
                d.py = y;
                return "translate(" + x + "," + y + ")";
            });

        this.link.filter(d => d.source.id === id || d.target.id === id)
            .attr("x1", (d) => {
                return d.source.x;
            })
            .attr("y1", (d) => {
                return d.source.y;
            })
            .attr("x2", (d) => {
                return d.target.x;
            })
            .attr("y2", (d) => {
                return d.target.y;
            })
    };

    bfs (node, nodes, comp) { // node -
        var qH = 0, qT = 0;
        var queue = [];
        var v;

        queue[qT++] = node;

        nodes[node].component = comp;
        nodes[node].used = true;

        while (qH < qT) { // пока очередь не пуста
            v = queue[qH++]; // извлекаем текущую вершину
            for (var nv = 0; nv < nodes.length; nv += 1) { // перебираем вершины
                // console.log(v, nv, queue);
                if (!nodes[nv].used && (nodes[v].related_nodes.indexOf(nodes[nv].id) != -1 || nodes[nv].related_nodes.indexOf(nodes[v].id) != -1)) { // если nv не помечена и смежна с v
                    /* <обработка вершины nv> */
                    nodes[nv].used = true; // помечаем ее
                    queue[qT++] = nv; // и добавляем в очередь
                    nodes[nv].component = comp;
                }
            }
        }
    }

    componentSearch (nodes) {
        for (let i = 0; i < nodes.length; i++) {
            nodes[i].used = false;
        }
        let comp = 0;
        for (var v = 0; v < nodes.length; v++){
            if (!nodes[v].used){
                this.bfs(v, nodes, comp);
                comp += 1;
            }
        }
        return comp
    }

    centerView () {
        //Center the view on the molecule(s) and scale it so that everything
        //fits in the window

        if (this.nodeGraph  === null)
            return;

        var nodes = this.nodeGraph.nodes;
        // var nodes = simulation.nodes;

        //no molecules, nothing to do
        if (nodes.length === 0)
            return;

        let nodeSizeConstant = 50;
        let nodeVerticalSizeConstant = 50;

        // Get the bounding box
        var min_x = d3.min(nodes.map(function(d) {return d.fx;})) - nodeSizeConstant;
        var min_y = d3.min(nodes.map(function(d) {return d.fy;})) - nodeVerticalSizeConstant;

        var max_x = d3.max(nodes.map(function(d) {return d.fx;})) + nodeSizeConstant;
        var max_y = d3.max(nodes.map(function(d) {return d.fy;})) + nodeVerticalSizeConstant;


        // The width and the height of the graph
        var mol_width = max_x - min_x ;
        var mol_height = max_y - min_y;

        // how much larger the drawing area is than the width and the height
        var width_ratio = this.width / mol_width;
        var height_ratio = this.height / mol_height;

        // we need to fit it in both directions, so we scale according to
        // the direction in which we need to shrink the most
        var min_ratio = Math.min(width_ratio, height_ratio) * 0.8;

        // the new dimensions of the molecule
        var new_mol_width = mol_width * min_ratio;
        var new_mol_height = mol_height * min_ratio;

        // translate so that it's in the center of the window
        var x_trans = -(min_x) * min_ratio + (this.width - new_mol_width) / 2;
        var y_trans = -(min_y) * min_ratio + (this.height - new_mol_height) / 2;


        // do the actual moving
        this.vis.attr("transform",
            "translate(" + [x_trans, y_trans] + ")" + " scale(" + min_ratio + ")");

        let selelction = d3.select("#vis");
        this.zoom_handler.scaleBy(this.svg_graph, min_ratio);
    }

    resetZoom() {
        let scale = 1.0;
        this.vis.attr("transform", "translate(0,0)scale(1,1)");
        // this.zoomer.scale(scale)
        //     .translate([0,0]);
    }

    onResize () {
        // this.width = this.configurations.element.clientWidth;
        // this.height = this.configurations.element.clientHeight;
        //
        // d3.select("#" + this.configurations.svgId).style("width", this.width);
        // d3.select("#" + this.configurations.svgId).style("height", this.height);
        //
        // if (this.globalSVG) {
        //     let indent = 0;
        //     this.globalSVG[0][0].setAttribute("width", this.width - indent);
        //     this.globalSVG[0][0].setAttribute("height", this.height);
        // }
        //
        // // reinit brush
        // d3.select(".brush rect").remove();
        //
        // let xScale = d3.scaleLinear()
        //     .domain([0,this.width]).range([0,this.width]);
        // let yScale = d3.scaleLinear()
        //     .domain([0,this.height]).range([0, this.height]);
        //
        // this.zoomer = d3.zoom()
        //     .scaleExtent([0.005,10])
        //     .x(xScale)
        //     .y(yScale)
        //     // .on("zoomstart", function(){$scope.zoomstart()})
        //     .on("zoom", () => {this.redraw()});
        //
        // this.brusher = d3.svg.brush()
        // //.x(d3.scale.identity().domain([0, width]))
        // //.y(d3.scale.identity().domain([0, height]))
        //     .x(xScale)
        //     .y(yScale)
        //     .on("brushstart", () => {
        //         this.node.each((d) => {
        //             if (d.visible) {
        //                 d.previouslySelected = this.shiftKey && d.selected;
        //             }
        //         });
        //     })
        //     .on("brush", () => {
        //         let extent = d3.event.target.extent();
        //
        //         this.node.classed("selected", (d) => {
        //             if (!d.visible) {
        //                 return false;
        //             }
        //             return d.selected = d.previouslySelected ^
        //                 (extent[0][0] <= d.x && d.x < extent[1][0]
        //                     && extent[0][1] <= d.y && d.y < extent[1][1]);
        //         });
        //
        //         this.graphState.selected = this.node.filter(n => n.selected && n.visible).enter().size().length;
        //         this.graphState.apply = false;
        //         this.onChange(this.graphState);
        //     })
        //     .on("brushend", function() {
        //         d3.event.target.clear();
        //
        //         d3.select(this).call(d3.event.target);
        //         // $scope.$apply();
        //     });
        //
        // d3.select(".brush-and-graph")
        //     .call(this.zoomer);
        //
        // d3.select(".brush")
        //     .datum(() => { return {selected: false, previouslySelected: false}; })
        //     .style("background-color", "rgba(255, 255, 255, 0.0)");
        //
        //
        // this.brush.call(this.brusher)
        //     .on("mousedown.brush", null)
        //     .on("touchstart.brush", null)
        //     .on("touchmove.brush", null)
        //     .on("touchend.brush", null);
        //
        // this.brush.select('.background').style('cursor', 'auto');
        // //end reinit brush
        //
        // this.centerView();
    }

    // keyup () {
    //     this.shiftKey = d3.event.shiftKey || d3.event.metaKey;
    //     this.ctrlKey = d3.event.ctrlKey;
    //
    //     // this.brush.call(this.brusher)
    //     //     .on("mousedown.brush", null)
    //     //     .on("touchstart.brush", null)
    //     //     .on("touchmove.brush", null)
    //     //     .on("touchend.brush", null);
    //     //
    //     // this.brush.select('.background').style('cursor', 'auto');
    //     // this.svg_graph.call(this.zoomer);
    // };
    //
    // keydown() {
    //     this.shiftKey = d3.event.shiftKey || d3.event.metaKey;
    //     this.ctrlKey = d3.event.ctrlKey;
    //     this.delKey = d3.event.key == "Delete";
    //
    //     if (this.ctrlKey) {
    //         if (d3.event.keyCode === 67) {   //the 'c' key
    //             this.copySelected();
    //         }
    //
    //         if (d3.event.keyCode === 32) {   //the space key
    //             this.centerView();
    //         }
    //
    //         // if (d3.event.keyCode == 13) { // the ented key
    //         //     $scope.$apply();
    //         // }
    //
    //         if (d3.event.keyCode === 73) {   //the 'i' key
    //             this.node.each(function (d) {
    //                 if (d.selected) {
    //                     d.selected = false;
    //                     d.previouslySelected = false;
    //                 } else {
    //                     d.selected = true;
    //                     d.previouslySelected = true;
    //                 }
    //             });
    //
    //             if (!this.shiftKey) {
    //                 //if the shift key isn't down, unselect everything
    //                 this.node.filter(function (p) {
    //                     return p.selected
    //                 }).classed("selected", true);
    //                 this.node.filter(function (p) {
    //                     return !p.selected
    //                 }).classed("selected", false);
    //             }
    //
    //             this.graphState.selected = this.node.filter(n => n.selected && n.visible).enter().size().length;
    //             this.graphState.apply = false;
    //             this.onChange(this.graphState);
    //             // this.configurations.apply();
    //         }
    //     }
    //
    //     if (this.shiftKey) {
    //         // this.svg_graph.call(this.zoomer)
    //         //     .on("mousedown.zoom", null)
    //         //     .on("touchstart.zoom", null)
    //         //     .on("touchmove.zoom", null)
    //         //     .on("touchend.zoom", null);
    //         //
    //         // //svg_graph.on('zoom', null);
    //         // this.vis.selectAll('g.gnode')
    //         //     .on('mousedown.drag', null);
    //         //
    //         // this.brush.select('.background').style('cursor', 'crosshair');
    //         // this.brush.call(this.brusher);
    //     }
    //
    //     if (this.delKey) {
    //         if (!this.ctrlKey){
    //             this.deleteByPredicate(this.deleteSelectedPred);
    //
    //         } else {
    //             this.deleteByPredicate(this.deleteUnSelectedPred);
    //         }
    //
    //         // previously hidden should stay hidden
    //         this.visibilityChange('substring', this.configurations.substring);
    //         this.visibilityChange('neighbour', this.configurations.min_neighbor);
    //         this.visibilityChange('degree', this.configurations.minNodeDegree);
    //
    //         this.graphState.nodes = this.node.filter(n => n.visible)[0].length;
    //         this.graphState.selected = this.node.filter(n => n.selected && n.visible).enter().size().length;
    //         this.graphState.apply = true;
    //         this.onChange(this.graphState);
    //
    //         this.processVisibleNodes(this.nodeGraph.nodes.filter(n => n.visible));
    //     }
    // }

    redraw () {
        this.vis.attr("transform", d3.event.transform);
    }

    brushstarted() {
        // keep track of whether we're actively brushing so that we
        // don't remove the brush on keyup in the middle of a selection
        this.brushing = true;

        this.node.each((d) => {
            d.previouslySelected = this.shiftKey && d.selected;
        });
    }

    brushed() {
        if (!d3.event.sourceEvent) return;
        if (!d3.event.selection) return;

        let extent = d3.event.selection;

        this.node.classed("selected", (d) => {
            return d.selected = d.previouslySelected ^
                (extent[0][0] <= d.x  && d.x  < extent[1][0]
                    && extent[0][1] <= d.y && d.y  < extent[1][1]);
        });
    }

    brushended() {
        if (!d3.event.sourceEvent) return;
        if (!d3.event.selection) return;
        if (!this.gBrush) return;

        this.gBrush.call(this.brush.move, null);

        if (!this.brushMode) {
            // the shift key has been release before we ended our brushing
            this.gBrush.remove();
            this.gBrush = null;
        }

        this.brushing = false;
    }

    keydown() {
        this.shiftKey = d3.event.shiftKey;

        if (this.shiftKey) {
            // if we already have a brush, don't do anything
            if (this.gBrush)
                return;

            this.brushMode = true;

            if (this.configurations.brushable && !this.gBrush) {
                this.gBrush = this.gBrushHolder.append('g');
                this.gBrush.call(this.brush);
            }
        }
    }

    keyup() {
        this.shiftKey = false;
        this.brushMode = false;

        if (!this.gBrush)
            return;

        if (!this.brushing) {
            // only remove the brush if we're not actively brushing
            // otherwise it'll be removed when the brushing ends
            this.gBrush.remove();
            this.gBrush = null;
        }
    }

    drawPngIcon (x, y) {
        let transformMatrix = 'matrix(' + '1' + ',0,0,' + '1' + ',' + x + ',' + y + ')';
        this.node.append("svg:circle")
        // .attr("x", function(d) { return x;})
        // .attr("y", function(d) { return y;})
            .attr("transform", transformMatrix)
            .attr("r", this.imgR*1.15)
            .attr("fill-opacity", "0")
            .attr("stroke-dasharray", "1 1")
            .style("stroke-width", function(d) { return 0.7 })
            .attr("class", "icon")
            .style("stroke", this.lineColor);

        this.node.append("svg:image")
            .attr("class", "icon")
            .attr("xlink:href", d => {
                return this.getPicture(d);
            })
            // .attr("clip-path", "url(#clip)")
            .attr("x", -this.imgR)
            .attr("y", -this.imgR)
            .attr("transform", transformMatrix)
            .attr("height", this.imgR*2)
            .attr("width", this.imgR*2)
            .style("-webkit-clip-path", "url(#clip)");
    }

    drawIcon (filter, type, scale, x, y) {
        let transformMatrix = 'matrix(' + scale + ',0,0,' + scale + ',' + x + ',' + y + ')';

        this.node.filter(d => filter(d))
        // .append("circle")
        // .attr("r", 5)
        // .attr("fill", d => this.getColor(d))
            .append("path")
            .attr("d",  type)
            .attr("transform", transformMatrix)
            .attr("class", "icon")
            .style("fill", (d) => {
                return this.getColor(d);
            });
    }

    appendIcon(view) {
        switch (view) {
            case 'normal':
                // first icon appearance
                this.drawIcon((d) => !this.specialView(d), this.logos.shoulders, 0.45, -3.5, -2.4);
                this.drawIcon((d) => !this.specialView(d), this.logos.head, 0.45, -2.0, -7.3);

                // special appearance, according to configuration.specialView()
                // appears as triple first view
                // central icon
                this.drawIcon((d) => this.specialView(d), this.logos.shoulders, 0.38, -3.5, -2.4);
                this.drawIcon((d) => this.specialView(d), this.logos.head, 0.38, -2.0, -6.8);
                // left icon
                this.drawIcon((d) => this.specialView(d), this.logos.shoulders, 0.28, -6.5,-2.4);
                this.drawIcon((d) => this.specialView(d), this.logos.head, 0.28, -5.5,-5.5);
                // right icon
                this.drawIcon((d) => this.specialView(d), this.logos.shoulders, 0.28, 1.0,-2.4);
                this.drawIcon((d) => this.specialView(d), this.logos.head, 0.28, 2.0,-5.5);

                break;
            case 'other':
                // second icon appearance
                this.drawIcon((d) => !this.specialView(d), this.logos.diagram, 0.02, -5, -8);

                // special appearance, according to configuration.specialView()
                // appears as triple first view
                // central icon
                this.drawIcon((d) => this.specialView(d), this.logos.shoulders, 0.38, -3.5, -2.4);
                this.drawIcon((d) => this.specialView(d), this.logos.head, 0.38, -2.0, -6.8);
                // left icon
                this.drawIcon((d) => this.specialView(d), this.logos.shoulders, 0.28, -6.5,-2.4);
                this.drawIcon((d) => this.specialView(d), this.logos.head, 0.28, -5.5,-5.5);
                // right icon
                this.drawIcon((d) => this.specialView(d), this.logos.shoulders, 0.28, 1.0,-2.4);
                this.drawIcon((d) => this.specialView(d), this.logos.head, 0.28, 2.0,-5.5);

                break;
            case 'picture':
                this.drawPngIcon(0, -2.5);
                break;
            case 'non':
                break;

        }
    }

    appendTextList (view) {
        d3.select("#" + this.configurations.svgId).selectAll("text").remove();

        let x1 = 0, x2 = 0, y = 0;

        if (view === 'picture') {
            y = 1.5*this.imgR;
        } else if (view !== 'non') { //с иконкой
            x1 = this.fontSize / 2;
            x2 = -6;
        } else { //без иконки
            x1 = this.fontSize / 2 - 5;
            x2 = 0;

            if (this.configurations.vertex_weight > 0 && this.configurations.vertex_weight < 6) {
                x1 += this.configurations.vertex_weight;
            }
        }

        let self = this;

        this.node.append("text")
            .each(function(d) {
                // get the current element
                let nameList = self.configurations.getNameList(d);
                var text = d3.select(this)
                    .attr("dx", (d) => {
                        if (d.fx > d.xcenter) {
                            return x1;
                        }
                        return x2;
                    })
                    .attr("x", (d) => {
                        if (d.fx > d.xcenter) {
                            return x1;
                        }
                        return x2;
                    })
                    .attr("text-anchor", (d) => {
                        if(view === "picture") {
                            return "middle"
                        }
                        if (d.fx > d.xcenter) {
                            return "start";
                        } else {
                            return "end";
                        }
                    })
                    .attr("y", y)
                    .attr("dy", nameList.length / 3 - (nameList.length-1) * 0.9 + 'em')
                    .style("font-size", self.fontSize + 'px')
                    .attr("class", "name")
                    .attr("fill", self.textColor)
                    .text(nameList[0]);
                // now loop
                for (var i = 1; i < nameList.length; i++) {
                    text.append("tspan")
                    // .attr('x', 0)
                        .attr("dx", (d) => {
                            if (d.fx > d.xcenter) {
                                return x1;
                            }
                            return x2;
                        })
                        .attr("x", (d) => {
                            if (d.fx > d.xcenter) {
                                return x1;
                            }
                            return x2;
                        })
                        .attr("text-anchor", (d) => {
                            if(view === "picture") {
                                return "middle"
                            }
                            if (d.fx > d.xcenter) {
                                return "start";
                            } else {
                                return "end";
                            }
                        })
                        .attr('dy', '1em')
                        .style("font-size", self.fontSize + 'px')
                        .attr("class", "name")
                        .attr("fill", self.textColor)
                        .text(nameList[i])
                }
            });
    }

    appendText (view) {
        let x1, x2, y;

        if (view === 'picture') {
            x1 = 0;
            x2 = 0;
            y = 0.7*this.imgR;
        } else if (view !== 'non') { //с иконкой
            x1 = this.fontSize / 2;
            x2 = -6;
        } else { //без иконки
            x1 = this.fontSize / 2 - 5;
            x2 = 0;


            if (this.configurations.vertex_weight > 0 && this.configurations.vertex_weight < 6) {
                x1 += this.configurations.vertex_weight;
            }
        }

        this.node.append("text")
            .attr("dx", (d) => {
                if (d.fx > d.xcenter) {
                    return x1;
                }
                return x2;
            })
            .attr("x", (d) => {
                if (d.fx > d.xcenter) {
                    return x1;
                }
                return x2;
            })
            .attr("text-anchor", (d) => {
                if(view === "picture") {
                    return "middle"
                }
                if (d.fx > d.xcenter) {
                    return "start";
                } else {
                    return "end";
                }
            })
            .attr("dy", y)
            .attr("y", y)
            .style("font-size", (d) => {
                if (this.configurations.vertex_weight > 0) {
                    let coef = d.related_links.length;
                    if (coef === 0) {
                        coef = 1;
                    }
                    return coef * this.configurations.vertex_weight + 'px'
                } else {
                    return this.fontSize + 'px';
                }
            })
            .attr("class", "name")
            .text((d) => {
                if (d.fx > d.xcenter){
                    return d.name;
                } else {
                    return d.name; }
            })
            .attr("fill", this.textColor);
    }

    appendNodePopover() {
        this.popover = this.vis.append("g")
            .attr("class", "popover")
            .selectAll(".popover").data(this.nodeGraph.nodes)
            .enter().append("div")
            .style("position", "absolute")
            .style("visibility", "hidden")
            .text("I'm a circle!");
    }

    appendLinkLabel (show) {
        if (show) {
            this.edgelabels = this.vis.append("g")
                .attr("class", "edgelabel")
                .selectAll(".edgelabel").data(this.nodeGraph.links)
                .enter()
                .append('text')
                .attr("opacity", 1)
                .style("pointer-events", "none")
                .attr({'class':'edgelabel',
                    'id': function(d){return 'edgelabel'+ d.id},
                    'dx': d => {
                        return (d.source.x + d.target.x)/2;
                    },
                    'dy': d => {
                        return (d.source.y + d.target.y)/2;
                    },
                })
                .style('font-size', this.fontSize/2 + 'px')
                .attr("fill", this.textColor)
                .style('stroke-width', '0px')
                .text(d => d.degree);
        } else {
            let svgToClean = d3.select("#" + this.configurations.svgId);
            svgToClean.selectAll(".edgelabel").remove();
        }


    }

    appendBoxToNodes () {
        var text = d3.select("text");
        var bbox = text.node().getBBox();
        var padding = 2;
        var rect = this.node.insert("rect", "text")
            .attr("x", bbox.x/2 - padding)
            .attr("y", bbox.y - padding)
            .attr("width", bbox.width/2 + (padding*2))
            .attr("height", bbox.height + (padding*2))
            .style("fill", "white")
            .style("opacity","0.6");
        // this.node.append("rect")
        //     .attr("x", (d) => {
        //         if (d.fx > d.xcenter) {
        //             return -8;
        //         }
        //         let box = d3.select("#" + this.configurations.svgId)
        //             .select("#" + d.id).node()
        //             .getBoundingClientRect();
        //         return - box.width;
        //
        //     })
        //
        //     .attr("y", (d) => {return  -1 * this.fontSize})
        //     .attr("width", (d) => {
        //         let box = d3.select("#" + this.configurations.svgId)
        //             .select("#" + d.id).node()
        //             .getBoundingClientRect();
        //         return box.width + 12;
        //     })
        //     .attr("height", (d) => {
        //         let box = d3.select("#" + this.configurations.svgId)
        //             .select("#" + d.id).node()
        //             .getBoundingClientRect();
        //         return box.height + 2;
        //     })
        //     .attr("opacity", 0);
    }

    refreshColors() {
        d3.select("#" + this.configurations.svgId).selectAll(".icon").style("fill", d => {
            return this.getColor(d);
        });
    }

    shadeColor(color, percent) {

        let R = parseInt(color.substring(1,3),16);
        let G = parseInt(color.substring(3,5),16);
        let B = parseInt(color.substring(5,7),16);

        R = parseInt(R * (100 + percent) / 100);
        G = parseInt(G * (100 + percent) / 100);
        B = parseInt(B * (100 + percent) / 100);

        R = (R<255)?R:255;
        G = (G<255)?G:255;
        B = (B<255)?B:255;

        let RR = ((R.toString(16).length==1)?"0"+R.toString(16):R.toString(16));
        let GG = ((G.toString(16).length==1)?"0"+G.toString(16):G.toString(16));
        let BB = ((B.toString(16).length==1)?"0"+B.toString(16):B.toString(16));

        return "#"+RR+GG+BB;
    }

    mouseover (d) {
        for (var i = 0; i < d.related_links.length; i++) {
            if (this.linksMap[d.related_links[i]].visible) {
                d3.select('#' + d.related_links[i]).style('stroke',
                    this.shadeColor(this.getLineColor(this.linksMap[d.related_links[i]]), -20));
            }
        }
    }

    mouseout (d) {
        for (var i = 0; i < d.related_links.length; i++) {
            if (this.linksMap[d.related_links[i]].visible){
                d3.select('#' + d.related_links[i]).style('stroke',
                    this.getLineColor(this.linksMap[d.related_links[i]]));
            }
        }
    }

    dragstarted (d) {
        if(d.visible) {
            // d3.event.sourceEvent.stopPropagation();
            // if (!d3.event.active) this.force.alphaTarget(0.3	).restart();

            self.force.stop();

            d.fx = d.x;
            d.fy = d.y;

            if (!d.selected && !self.shiftKey) {
                // if this node isn't selected, then we have to unselect every other node
                self.node.classed("selected", p => { return p.selected =  p.previouslySelected = false; });
            }

            // how does it work? what THIS?
            d3.select(this).classed("selected", p => { p.previouslySelected = p.selected; return p.selected = true; });

            self.graphState.selected = self.node.filter(n => n.selected && n.visible).enter().size().length;
            self.graphState.apply = true;
            self.onChange(self.graphState);

            // node.filter(function(d) { return d.selected; })
            // .each(function(d) { d.fixed |= 2; })
        }
    }

    dragended (p) {
        //d3.select(self).classed("dragging", false);
        // this.node.filter(d => { return d.selected; })
        //     .each(function(d) { d.fixed &= ~6; })

        // if (!d3.event.active) this.force.alphaTarget(0);

        p.fx = p.x;
        p.fy = p.y;
        // this.node.filter(function(d) { return d.selected; })
        //   .each(d => {
        //     d.fx += d3.event.x;
        //     d.fy += d3.event.y;
        //
        //     d.x += d3.event.x;
        //     d.y += d3.event.y;
        //   });

        // this.force.tick();

    }

    dragged (p) {
        p.fx = d3.event.x;
        p.fy = d3.event.y
        // console.log('drag', d3.event.x, d3.event.y);
        // this.node.filter(function(d) { return d.selected; })
        //     .each(d => {
        //         d.x += d3.event.x;
        //         d.y += d3.event.y;
        //
        //         d.fx += d3.event.x;
        //         d.fy += d3.event.y;
        //
        //         if (this.configurations.nodeTranslateMap && d.staticId) {
        //             this.configurations.nodeTranslateMap[d.staticId] = {x:  d.px, y: d.py};
        //         }
        //
        //     });

        // this.force.resume();
    }

    removeSVG (key, callback) {
        var svgToClean = d3.select("#" + this.configurations.svgId);
        svgToClean.selectAll("line").remove();
        svgToClean.selectAll("text").remove();
        svgToClean.selectAll("path.icon").remove();

        this.node = null;
        this.link = null;

        if(callback && typeof callback === 'function'){
            callback(key, this);
        }
    }

    isSelected () {
        let is_selected = false;
        d3.select("#" + this.configurations.svgId).selectAll("text").style("opacity", function(d){
            if (d.selected){
                is_selected = true;
            }
        });

        return is_selected;
    };

    isDeleted() {
        let is_deleted = false;
        d3.select("#" + this.configurations.svgId).selectAll("text").style("opacity", function(d){
            if (d.deleted){
                is_deleted = true;
            }
        });

        return is_deleted;
    }

    createSvgString (svgElem) {
        let svgString = '';

        if (svgElem) {
            let XMLS = new XMLSerializer();
            svgString = XMLS.serializeToString(svgElem); // по идее svgElem.outrHTML тоже работает
        }

        return svgString;
    }

    makeSvg () {
        let svgElem = d3.select('#' + this.configurations.svgId);
        if (svgElem && svgElem.node()) {
            return this.createSvgString(svgElem.node());

        } else {
            return 'svg is empty';
        }

    }

    deleteSelectedPred(node){
        return node.selected || node.deleted ;
    }

    deleteUnSelectedPred(node){
        return !node.selected || node.deleted;
    }

    deleteSelectedNodes() {
        this.deleteByPredicate(this.deleteSelectedPred);

        this.visibilityChange('substring', this.configurations.substring);
        this.visibilityChange('neighbour', this.configurations.min_neighbor);
        this.visibilityChange('degree', this.configurations.minNodeDegree);

        this.graphState.nodes = this.node.filter(n => n.visible)[0].length;
        this.graphState.selected = this.node.filter(n => n.selected && n.visible).enter().size().length;
        this.graphState.apply = false;
        this.onChange(this.graphState);

        this.processVisibleNodes(this.nodeGraph.nodes.filter(n => n.visible));
    }

    showDeletedNodes () {
        let old_nodes = this.nodeGraph.nodes;
        for (var i = 0; i < old_nodes.length; i += 1) {
            if(this.nodeGraph.nodes[i].deleted){
                this.showNode(this.nodeGraph.nodes[i]);
            }
        }

        this.visibilityChange('substring', this.configurations.substring);
        this.visibilityChange('neighbour', this.configurations.min_neighbor);
        this.visibilityChange('degree', this.configurations.minNodeDegree);


        this.graphState.nodes = this.node.filter(n => n.visible)[0].length;
        this.graphState.selected = this.node.filter(n => n.selected && n.visible).enter().size().length;
        this.graphState.apply = false;
        this.onChange(this.graphState);

        this.processVisibleNodes(this.nodeGraph.nodes.filter(n => n.visible));

    }

    showNode (n) {
        n.visible = true;
        n.deleted = false;
        // for (var i = 0; i < n.edges.length; i += 1){
        //     nodeGraph.links[n.edges[i]].visible = true;
        // }
        for(var i = 0; i < this.nodeGraph.links.length; i += 1){
            if (this.nodeGraph.links[i].id.indexOf(n.id) != -1) {
                this.nodeGraph.links[i].visible = true;
            }
        }
    };

    hideSelectedNodes (){
        this.hideByPredicate(this.deleteSelectedPred);

        this.visibilityChange('substring', this.configurations.substring);
        this.visibilityChange('neighbour', this.configurations.min_neighbor);
        this.visibilityChange('degree', this.configurations.minNodeDegree);

        this.graphState.nodes = this.node.filter(n => n.visible)[0].length;
        this.graphState.selected = this.node.filter(n => n.selected && n.visible).enter().size().length;
        this.graphState.apply = false;
        this.onChange(this.graphState);

        this.processVisibleNodes(this.nodeGraph.nodes.filter(n => n.visible));
    }

    hideUnSelectedNodes (){
        this.hideByPredicate(this.deleteUnSelectedPred);

        this.visibilityChange('substring', this.configurations.substring);
        this.visibilityChange('neighbour', this.configurations.min_neighbor);
        this.visibilityChange('degree', this.configurations.minNodeDegree);

        this.graphState.nodes = this.node.filter(n => n.visible)[0].length;
        this.graphState.selected = this.node.filter(n => n.selected && n.visible).enter().size().length;
        this.graphState.apply = false;
        this.onChange(this.graphState);

        this.processVisibleNodes(this.nodeGraph.nodes.filter(n => n.visible));
    }

    filterSelectedNodes (){
        this.filterByPredicate(this.deleteSelectedPred);

        this.visibilityChange('substring', this.configurations.substring);
        this.visibilityChange('neighbour', this.configurations.min_neighbor);
        this.visibilityChange('degree', this.configurations.minNodeDegree);

        this.graphState.nodes = this.node.filter(n => n.visible)[0].length;
        this.graphState.selected = this.node.filter(n => n.selected && n.visible).enter().size().length;
        this.graphState.apply = false;
        this.onChange(this.graphState);

        this.processVisibleNodes(this.nodeGraph.nodes.filter(n => n.visible));
    }

    filterUnSelectedNodes () {
        this.filterByPredicate(this.deleteUnSelectedPred);

        this.visibilityChange('substring', this.configurations.substring);
        this.visibilityChange('neighbour', this.configurations.min_neighbor);
        this.visibilityChange('degree', this.configurations.minNodeDegree);

        this.graphState.nodes = this.filterIds.count;
        this.graphState.selected = this.node.filter(n => n.selected && n.visible).enter().size().length;
        this.graphState.apply = false;
        this.onChange(this.graphState);

        this.processVisibleNodes(this.nodeGraph.nodes.filter(n => n.visible));
    }

    hideByPredicate (pred) {
        // скрываем подпись если
        //      выполняется предикат |
        //      вершина удалена
        d3.select("#" + this.configurations.svgId).selectAll("text.name").attr("opacity", function (d) {
            if (pred(d) || d.deleted || d.filtered) {
                // d.selected = false;
                d.visible = false;
                return 0;
            } else {
                return 1;
            }
        });


        // снимаем выделение если
        //      выполняется предикат |
        //      вершина удалена
        d3.select("#" + this.configurations.svgId).selectAll(".node,.selected").classed("selected", function (d) {
            if (d && d.related_links) {
                if (pred(d) || d.deleted || d.filtered) {
                    d.selected = false;
                    return false;
                } else {
                    return d.selected;
                }
            }

        });

        // скрываем иконку если
        //      выполняется предикат |
        //      вершина удалена
        d3.select("#" + this.configurations.svgId).selectAll(".icon").attr("opacity", function (d) {
            if (pred(d) || d.deleted || d.filtered) {
                return 0;
            } else {
                return 1;
            }
        });


        // мняем курсор на подписи на обычный если
        //      выполняется предикат |
        //      вершина удалена
        d3.select("#" + this.configurations.svgId).selectAll("text.name").style("cursor", function (d) {
            if (pred(d) || d.deleted || d.filtered) {
                return 'context-menu';
            } else {
                return 'pointer';
            }
        });

        // мняем курсор на иконке на обычный если
        //      выполняется предикат |
        //      вершина удалена
        d3.select("#" + this.configurations.svgId).selectAll(".icon").style("cursor", function (d) {
            if (pred(d) || d.deleted || d.filtered) {
                return 'context-menu';
            } else {
                return 'pointer';
            }
        });


        // открываем всех, на ком не срабатывает прдикаи и кто не удален, и все их связи
        d3.select("#" + this.configurations.svgId).selectAll(".name").style("opacity",  (d) => {
            if (!pred(d) && !d.deleted && !d.filtered) {
                d.visible = true;
                for (var i = 0; i < d.related_links.length; i++) {
                    this.linksMap[d.related_links[i]].visible = true;
                    d3.select('#' + d.related_links[i]).style('opacity', 1);
                    d3.select('#edgelabel' + d.related_links[i]).attr('opacity', 1);
                }
                return 1;
            }
        });

        // скрываем всех, на ком выполняется предикаи или тех, кто удален, и все их связи
        d3.select("#" + this.configurations.svgId).selectAll(".name").attr("opacity", (d) => {
            if (pred(d) || d.deleted || d.filtered) {
                d.visible = false;
                for (var i = 0; i < d.related_links.length; i++) {
                    this.linksMap[d.related_links[i]].visible = false;
                    d3.select('#' + d.related_links[i]).style('opacity', 0);
                    d3.select('#edgelabel' + d.related_links[i]).attr('opacity', 0);
                }
                return 0;
            } else {
                return 1;
            }
        });
    }

    selectByPredicate (pred) {
        // // снимаем выделение если
        // // предикат не выполняется
        // d3.select("#" + this.configurations.svgId).selectAll(".node,.selected").classed("selected", function (d) {
        //     if (d && d.related_links) {
        //         if (!pred(d)) {
        //             d.selected = false;
        //             return false;
        //         } else {
        //             return d.selected;
        //         }
        //     }
        //
        // });

        //  выделяем если
        //  предикат выполняется
        d3.select("#" + this.configurations.svgId).selectAll(".node").classed("selected", function (d) {
            if (d && d.related_links) {
                if (!pred(d)) {
                    d.selected = true;
                    return true;
                } else {
                    d.selected = false;
                    return false;
                }
            }
        });
    }

    deleteByPredicate(pred) {
        d3.select("#" + this.configurations.svgId).selectAll("text.name").attr("a", (d) => {
            if (pred(d)) {
                d.deleted = true;
            }
        });
        this.hideByPredicate(pred);
    }

    filterByPredicate(pred) {
        d3.select("#" + this.configurations.svgId).selectAll("text.name").attr("a", (d) => {
            if (pred(d)) {
                d.filtered = true;
            }
        });
        this.hideByPredicate(pred);
    }

    makeFilter (filter_pattern) {
        let pattern_list = filter_pattern.split(/[\s,\+]+/);

        let condition = (node) => {
            if (!node.name) {
                return false;
            }

            let preresult = true;
            for (let pattern of pattern_list) {
                var dotIndex = pattern.indexOf("...");
                switch (dotIndex) {
                    //указан постфикс
                    case 0:
                        if (pattern != '') {
                            let essence = pattern.substr(3);
                            let target = node.name.substr(node.name.length - essence.length);
                            preresult = preresult && (essence != target);
                            // return node.name.indexOf($scope.suffixRegex.substr(3)) != node.name.length - $scope.suffixRegex.substr(3).length;
                        }
                        break;
                    //указан суффикс
                    case -1:
                        if (pattern != '') {
                            preresult = preresult && (node.name.indexOf(pattern) === -1);
                        }
                        break;
                    //указан префикс
                    case pattern.length - 3:
                        if (pattern != '') {
                            preresult = preresult && (node.name.indexOf(pattern.substr(0, pattern.length - 3)) != 0);
                        }
                        break;
                }
                if (pattern === 0 || pattern === '...') {
                    preresult = false;
                }
            }
            return preresult;
        };

        return condition;
    }

    constructCondition(filterType, curFilter) {
        switch(filterType) {
            case 'neighbour':
                this.minNeighbourNodesNumber = curFilter;
                this.filterMap.neighbour = (node) => {
                    if (node === 0) {
                        return true
                    }
                    return node.related_links.length < this.minNeighbourNodesNumber;
                };
                break;

            case 'substring':
                this.searchPattern = curFilter;

                if (this.searchPattern == '' || this.searchPattern == null || this.searchPattern == '...') {
                    this.filterMap.substring = (node) => {
                        return false;
                    }
                } else {
                    this.filterMap.substring = this.makeFilter(this.searchPattern);
                }
                break;

            case 'degree':
                this.minNodeDegree = curFilter;
                this.filterMap.degree = (node) => {
                    if (node === 0) {
                        return true
                    }

                    let sumDegree = 0;
                    for (let link of node.related_links) {
                        if (this.linksMap[link].degree) {
                            sumDegree += this.linksMap[link].degree;
                        }
                    }

                    return sumDegree < this.minNodeDegree;
                };
                break;

                break;
        }

        let self = this;
        let condition = function (node) {
            return  self.filterMap.substring(node) ||
                self.filterMap.neighbour(node) ||
                self.filterMap.degree(node);
        };

        return condition;
    }

    visibilityChange (filterType, curFilter) {

        // this.hideByPredicate(this.constructCondition(filterType, curFilter));
        //
        // this.graphState.nodes = this.node.filter(n => n.visible)[0].length;
        // this.graphState.selected = this.node.filter(n => n.selected && n.visible).enter().size().length;
        // this.graphState.apply = false;
        // this.onChange(this.graphState);
        //
        // this.processVisibleNodes(this.nodeGraph.nodes.filter(n => n.visible));
    }

    selectChange (filterType, curFilter) {
        if (curFilter === "" || curFilter === undefined) {
            this.selectByPredicate(node => true);
        } else {
            this.selectByPredicate(this.constructCondition(filterType, curFilter));
        }

        this.graphState.nodes = this.node.filter(n => n.visible)[0].length;
        this.graphState.selected = this.node.filter(n => n.selected && n.visible).enter().size().length;
        this.graphState.apply = false;
        this.onChange(this.graphState);

        this.processVisibleNodes(this.nodeGraph.nodes.filter(n => n.visible));
    }

    resize (byValue) {
        let currentSizing = byValue;

        switch(byValue) {
            case "nodes":
                this.vertexDegree = 1;
                d3.select("#" + this.configurations.svgId).selectAll("text.icon").style("font-size", this.fontSize);
                d3.select("#" + this.configurations.svgId).selectAll("text.name").style("font-size", this.fontSize);
                d3.select("#" + this.configurations.svgId).selectAll("text.name").attr("dx", (d) => {
                    if (d.fx > d.xcenter) {
                        return this.fontSize / 2
                    }
                    return -5;

                });
                break;

            case "links":
                d3.select("#" + this.configurations.svgId).selectAll("line").style("stroke-width", 1);
                this.linkDegree = 0;
                break;

            case "nothing":
                this.linkDegree = 0;
                this.vertexDegree = 1;
                this.configurations.vertex_weight = 0;
                this.configurations.edge_weight = 0;

                d3.select("#" + this.configurations.svgId).selectAll("text.icon").style("font-size", this.fontSize);
                d3.select("#" + this.configurations.svgId).selectAll("text.name").style("font-size", this.fontSize);
                d3.select("#" + this.configurations.svgId).selectAll("line").style("stroke-width", 1);
                d3.select("#" + this.configurations.svgId).selectAll("text.name").attr("dx", (d) => {
                    if (d.fx > d.xcenter) {
                        return this.fontSize / 2
                    }
                    return -5;
                });

                break;
            case "degree":
                this.centerView();
                d3.select("#" + this.configurations.svgId).selectAll("text.icon").style("font-size", (d) => {
                    return this.fontSize + d.degree + 'px';
                });

                d3.select("#" + this.configurations.svgId).selectAll("text.name").style("font-size", (d) => {
                    return this.fontSize + d.degree + 'px'
                });
                d3.select("#" + this.configurations.svgId).selectAll("text.name").attr("dx", (d) => {
                    if (d.fx > d.xcenter) {
                        return (this.fontSize + d.degree) / 2
                    }
                    return -5;
                });
                break;
        }
    }

    nodeChange (vertexDegree) {
        //This function now accounts for the size of the circle but bases that size off of the fixed childNode position of the circle in the g element (position [0] in this implementation)
        if (vertexDegree <= 0) {
            this.resize('nodes');
            return;
        }

        d3.select("#" + this.configurations.svgId).selectAll("text.name").attr("dx", (d) => {
            if (d.fx > d.xcenter) {
                if (vertexDegree <= 6){
                    return this.fontSize / 2;
                } else {
                    return d.related_links.length * vertexDegree / 2;
                }
            }
            return -5;
        });

        d3.select("#" + this.configurations.svgId).selectAll("text.name").style("font-size", (d) => {
            let coef = d.related_links.length;
            if (coef === 0) {
                coef = 1;
            }
            return coef * vertexDegree + 'px';
        });
    }

    linkChange (linkDegree) {

        if (linkDegree <= 0) {
            this.resize('links');
            return;
        }

        d3.select("#" + this.configurations.svgId).selectAll("line").filter(d => {return d.id}).style("stroke-width", (d) => {
            if(d.id) {
                return 1 + d.degree*linkDegree/this.maxDegree;
            }
        });
    }

    lineDash(view) {
        switch (view) {
            case "normal":
            case "other":
                d3.select("#" + this.configurations.svgId).selectAll("line").filter(d => {return d.id}).attr("stroke-dasharray", "");
                d3.select("#" + this.configurations.svgId).selectAll("line").filter(d => {return d.id}).attr("marker-start","");
                d3.select("#" + this.configurations.svgId).selectAll("line").filter(d => {return d.id}).attr("marker-end","");

                break;
            case "picture":
                d3.select("#" + this.configurations.svgId).selectAll("line").filter(d => {return d.id}).attr("stroke-dasharray", "1 1");
                d3.select("#" + this.configurations.svgId).selectAll("line").filter(d => {return d.id}).attr("marker-start","url(#point)");
                d3.select("#" + this.configurations.svgId).selectAll("line").filter(d => {return d.id}).attr("marker-end","url(#point)");

                this.configurations.edge_weight = 0;
                this.linkChange(this.configurations.edge_weight);
                break;
        }
    }

    changeIconAppearance (view) {
        if (this.configurations.currentNodeAppearance === 2 || !this.node) {
            return;
        }

        this.configurations.currentIconAppearance = view;

        let svgToClean = d3.select("#" + this.configurations.svgId);
        svgToClean.selectAll("path.icon").remove();
        svgToClean.selectAll("circle.icon").remove();
        svgToClean.selectAll("image.icon").remove();
        svgToClean.selectAll("text").remove();

        this.appendIcon(view);
        this.lineDash(view);
        if (this.configurations.getNameList instanceof Function) {
            this.appendTextList(view)
        } else {
            this.appendText(view);
        }
        this.appendLinkLabel(this.configurations.showDegree);

        this.tick();

        this.visibilityChange('substring', this.configurations.substring);
        this.visibilityChange('neighbour', this.configurations.min_neighbor);
        this.visibilityChange('degree', this.configurations.minNodeDegree);

    }

    changeNodeAppearance (view) {
        if (!this.node) {
            return;
        }
        this.configurations.currentNodeAppearance = view;
        let svgToClean = d3.select("#" + this.configurations.svgId);
        svgToClean.selectAll("path.icon").remove();
        svgToClean.selectAll("circle.icon").remove();
        svgToClean.selectAll("image.icon").remove();
        svgToClean.selectAll("text").remove();
        //$scope.currentNodeAppearance = view;

        if (this.configurations.getNameList instanceof Function) {
            this.appendTextList(view)
        } else {
            this.appendText(view);
        }
        this.appendLinkLabel(this.configurations.showDegree);
        this.changeIconAppearance(this.configurations.currentIconAppearance);
        this.visibilityChange('substring', this.configurations.substring);
        this.visibilityChange('neighbour', this.configurations.min_neighbor);
        this.visibilityChange('degree', this.configurations.minNodeDegree);
    }

    copyTextToClipboard (text) {
        let textArea = document.createElement("textarea");
        //
        // *** This styling is an extra step which is likely not required. ***
        //
        // Why is it here? To ensure:
        // 1. the element is able to have focus and selection.
        // 2. if element was to flash render it has minimal visual impact.
        // 3. less flakyness with selection and copying which **might** occur if
        //    the textarea element is not visible.
        //
        // The likelihood is the element won't even render, not even a flash,
        // so some of these are just precautions. However in IE the element
        // is visible whilst the popup box asking the user for permission for
        // the web page to copy to the clipboard.
        //

        // Place in top-left corner of screen regardless of scroll position.
        textArea.style.position = 'fixed';
        textArea.style.top = 0;
        textArea.style.left = 0;

        // Ensure it has a small width and height. Setting to 1px / 1em
        // doesn't work as this gives a negative w/h on some browsers.
        textArea.style.width = '2em';
        textArea.style.height = '2em';

        // We don't need padding, reducing the size if it does flash render.
        textArea.style.padding = 0;

        // Clean up any borders.
        textArea.style.border = 'none';
        textArea.style.outline = 'none';
        textArea.style.boxShadow = 'none';

        // Avoid flash of white box if rendered for any reason.
        textArea.style.background = 'transparent';


        textArea.value = text;

        document.body.appendChild(textArea);

        textArea.select();

        try {
            let successful = document.execCommand('copy');
            let msg = successful ? 'successful' : 'unsuccessful';
        } catch (err) {
            console.error(err);
        }

        document.body.removeChild(textArea);
    }

    copySelected () {
        if (this.configurations.graphdata.nodes) {
            let selectedNodes = this.configurations.graphdata.nodes.filter(function (p) {
                return p.selected
            });

            let text = selectedNodes.map(function (d) {
                return d.name;
            }).join(", ");

            this.copyTextToClipboard(text);
        }
    }

    inverseSelection() {
        if (this.node) {
            this.node.each(function (d) {
                if (d.selected) {
                    d.selected = false;
                    d.previouslySelected = false;
                } else {
                    d.selected = true;
                    d.previouslySelected = true;
                }
            });

            this.node.filter(function (p) {
                return p.selected
            }).classed("selected", true);
            this.node.filter(function (p) {
                return !p.selected
            }).classed("selected", false);

            this.graphState.selected = this.node.filter(n => n.selected && n.visible).enter().size().length;
            this.graphState.apply = false;
            this.onChange(this.graphState);

            // this.configurations.updateSelectedCount(node.filter(n => n.selected && n.visible)[0].length);
        }
    }

    selectConnectedComponent () {
        if (this.configurations.graphdata.nodes) {
            let selectedNodes = this.configurations.graphdata.nodes.filter(function(p){return p.selected});
            for (let i = 0; i < selectedNodes.length; i++) {
                this.configurations.graphdata.nodes.map(function(d){
                    if (d.component == selectedNodes[i].component) {
                        d.selected = true;
                    }
                });
            }

            this.node.filter(function(p){return p.selected}).classed("selected", true);

            this.graphState.selected = this.node.filter(n => n.selected && n.visible).enter().size().length;
            this.graphState.apply = false;
            this.onChange(this.graphState);
        }
    }

    nodeChangeSelected (nodeDistinctSize) {
        //This function now accounts for the size of the circle
        // but bases that size off of the fixed childNode position
        // of the circle in the g element (position [0] in this implementation)

        if(nodeDistinctSize <= 0) {
            this.resize('nothing');
            return;
        }


        d3.select("#" + this.configurations.svgId).selectAll(".icon").filter( function(d) { return d.selected } ).style("font-size", function(d){
            return nodeDistinctSize + 'px';
        });

        d3.select("#" + this.configurations.svgId).selectAll(".name").filter( function(d) { return d.selected } ).attr("dx", function(d){
            if (d.fx > d.xcenter) {
                if (nodeDistinctSize <= 6){
                    return this.fontSize / 2;
                } else {
                    return nodeDistinctSize / 2
                }
            }
            return -5;
        });

        d3.select("#" + this.configurations.svgId).selectAll(".name").filter( function(d){ return d.selected } ).style("font-size", function(d){
            return nodeDistinctSize + 'px'});
    }

    getGraph(){
        return this.nodeGraph;
    }
}

