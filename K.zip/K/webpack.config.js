const path = require('path');

const NODE_ENV = process.env.NODE_ENV ? process.env.NODE_ENV : 'production';

module.exports = {
  entry: './src/ts/index.ts',
  devtool: 'inline-source-map',
  mode: NODE_ENV,
  watch: NODE_ENV === 'development',
  output: {
    path: path.resolve(__dirname, 'dist'),
    filename: 'bundle.js'
  },
  resolve: {
    extensions: ['.tsx', '.ts', '.js'],
  },
  module: {
    rules: [
      {
        test: /\.tsx?$/,
        use: 'ts-loader',
        exclude: /node_modules/,
      },
    ],
  }
};
