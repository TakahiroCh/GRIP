#source ~/.../emsdk/emsdk_env.sh
em++ src/cpp/src/main.cpp -s WASM=1 -o dist/wasm/wasm.js -s FORCE_FILESYSTEM=1 -std=c++14 -s MODULARIZE=1 --bind
