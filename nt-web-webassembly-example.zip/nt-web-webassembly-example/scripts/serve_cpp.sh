emrun --no_browser --port 8080 index.html
