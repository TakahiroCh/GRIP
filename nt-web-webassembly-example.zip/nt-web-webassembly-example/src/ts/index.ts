import {loadWasm} from "./wasm/utils";

loadWasm().then(wasm => {
  console.log('WASM loaded.');

  const tsEntities = [
    {id: 1, label: "label1", friends: [2]},
    {id: 3, label: "label3", friends: []},
    {id: 2, label: "label2", friends: [1]},
  ] as {id: number, label: string, friends: number[]}[];

  const cppEntities = wasm.newVector$Entity$();
  tsEntities.forEach(e => {
    const cppFriends = wasm.newVector$unsigned_int$();
    e.friends.forEach(f => cppFriends.push_back(f));

    cppEntities.push_back({
      id: e.id,
      label: e.label,
      friends: cppFriends
    })
  });


  console.log('entities:')
  for (let i = 0; i < cppEntities.size(); i++) {
    console.log(cppEntities.get(i));
  }
  wasm.sortById(cppEntities);
  console.log('sorted entities:')
  for (let i = 0; i < cppEntities.size(); i++) {
    console.log(cppEntities.get(i));
  }
});
