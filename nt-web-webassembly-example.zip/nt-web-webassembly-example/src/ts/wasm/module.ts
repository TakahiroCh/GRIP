import {CppVector} from "./models/cpp-vector";
import {CppEntity} from "./models/cpp-entity";

/**
 * Ручное описание типов/функций, заданных в main.cpp при помощи Embind.
 * Делается для удобства использования.
 *
 */
export interface WasmModule {
  module: any;
  newVector$unsigned_int$(): CppVector<number>;
  newVector$Entity$(): CppVector<CppEntity>;
  sortById(entities: CppVector<CppEntity>): void;
}
