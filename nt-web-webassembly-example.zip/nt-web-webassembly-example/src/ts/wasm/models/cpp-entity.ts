import {CppVector} from "./cpp-vector";

/**
 * Описание сущности Entity, заданной в main.cpp
 */
export interface CppEntity {
  id: number;
  label: string;
  friends: CppVector<number>;
}
