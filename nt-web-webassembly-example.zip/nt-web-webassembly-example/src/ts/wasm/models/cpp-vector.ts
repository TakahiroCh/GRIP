/**
 * Краткое описание класса std::vector<T>
 */
export interface CppVector<T> {
  size(): number;
  get(i: number): T;
  push_back(v: T);
  delete();
}
