import {WasmModule} from "./module";
import {CppVector} from "./models/cpp-vector";
import {CppEntity} from "./models/cpp-entity";

/**
 * Загрузка wasm-модуля
 */
export function loadWasm() {
  return new Promise<WasmModule>((resolve, reject) => {
    // @ts-ignore
    Module().then((module) => {
      delete module.then;
      resolve(bindWasmModule(module));
    });
  });
}

/**
 * Привязка типов/функций, заданных в main.cpp при помощи Embind.
 * Делается для удобства использования.
 *
 * @param module - загруженный wasm-модуль
 */
function bindWasmModule(module: any): WasmModule {
  return {
    ['module']: module,
    newVector$unsigned_int$(): CppVector<number> {
      return new module.vector$unsigned_int$();
    },
    newVector$Entity$(): CppVector<CppEntity> {
      return new module.vector$Entity$();
    },
    sortById(entities: CppVector<CppEntity>): CppVector<CppEntity> {
      return module.sortById(entities);
    }
  };
}
