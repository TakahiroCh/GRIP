#include <iostream>
#include <vector>

#include "Entity.h"

#include <emscripten/bind.h>

using namespace emscripten;



void sortById(std::vector<Entity> &entities) {
    std::cout << "sortById()" << std::endl;
    std::sort(entities.begin(), entities.end(), [](Entity &a, Entity &b) {
        return a.id < b.id;
    });
}



EMSCRIPTEN_BINDINGS() {
    function("sortById", &sortById);

    value_object<Entity>("Entity")
            .field("id", &Entity::id)
            .field("label", &Entity::label)
            .field("friends", &Entity::friends)
            ;
    register_vector<Entity>("vector<Entity>");
    register_vector<unsigned int>("vector<unsigned_int>");
}

int main() {
    return 0;
}
