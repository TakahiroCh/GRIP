#ifndef ENTITY_H
#define ENTITY_H

#include <string>
#include <vector>

struct Entity {
    unsigned int id;
    std::string label;
    std::vector<unsigned int> friends;
};

#endif //ENTITY_H
