# nt-web-webassembly-example

---

## Установка и запуск

---

Установить [Emscripten][1]

Собрать front-end:
```
yarn install
yarn build
```

Скомпилировать исходники на `c++` и запустить проект:
```
yarn build-cpp
yarn serve-cpp
```

## c++

---

Описание сущностей задается в файле `main.cpp` при помощи [Embind][2]  
Embind позволяет осуществлять передачу различных типов сущностей между `c++` и `js/ts` в обоих направлениях


## js/ts

---

Описанные функции и сущности можно использовать после выполнения загрузки `wasm`-модуля
при помощи функции `loadWasm()` из `src/ts/wasm/utils.ts`



[1]: https://emscripten.org/docs/getting_started/downloads.html "Установка Emscripten"
[2]: https://emscripten.org/docs/porting/connecting_cpp_and_javascript/embind.html "Embind"
