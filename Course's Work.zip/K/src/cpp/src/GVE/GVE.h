#pragma once

#ifndef T_GVE
#define T_GVE

#include <iostream>
#include <vector>
#include <string>
#include <set>
#include <map>

#include "../VertexDesc/VertexDesc.h"

#include "../Point/Point.h"

class Vertex;
class Edge;


class Graph {
private:
	std::vector<Vertex> vertices;

public:
	explicit Graph();
	Graph(const std::vector<VertexDesc>& vertices);

	const unsigned int getVertexSize() const;
	inline Vertex& getVertex(unsigned int id);
	Vertex& addVertex(const std::string& name, const Point& pos);
	void connect(unsigned int id1, unsigned int id2, unsigned int degree);
	std::set<Edge> getEdges();
	std::vector<Vertex> getVertexes();
	std::vector<VertexDesc> getSimpleDescription();
};

class Vertex {
private:
	Graph& graph;
	const std::string name;
	const unsigned int id;
	Point pos;
	std::vector<Edge> edges;

public:
	explicit Vertex(Graph& graph, unsigned int id, const std::string name, const Point& position);
	inline unsigned int getId() const;
	inline std::string getName() const;
	inline const Point getPos() const;
	const std::vector<Edge> getEdges() const;

	void setPos(const Point pos);
	void connect(Vertex& other, unsigned int degree);

	inline Vertex& find(Edge edge);
	std::vector<Vertex> getNeighbours();
	std::vector<unsigned int> getNeighboursId();

	friend std::ostream& operator<<(std::ostream& out, const Vertex& v);
};


class Edge {
private:
	const unsigned int v1;
	const unsigned int v2;
	const unsigned int degree;

public:
	explicit Edge(unsigned int v1, unsigned int v2, unsigned int degree = 1);
	inline unsigned int _1() const;
	inline unsigned int _2() const;
	inline unsigned int getDegree() const;
	unsigned int getNeighbhour(unsigned int v) const;

	bool operator==(const Edge& e) const;
	bool operator<(const Edge& e) const;
	friend std::ostream& operator<<(std::ostream& out, const Edge& e);
};


#endif 
