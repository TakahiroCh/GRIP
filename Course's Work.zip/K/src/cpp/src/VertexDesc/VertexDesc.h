#ifndef T_VERTEX_DESC
#define T_VERTEX_DESC

#include <string>
#include <vector>

struct VertexDesc {
	unsigned int id;
	std::string label;
	double x;
	double y;
	std::vector<unsigned int> vertices;
};

#endif
