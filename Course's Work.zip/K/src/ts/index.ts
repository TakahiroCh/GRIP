import {ArrangeConfig} from "./models/WasmModule";
import {loadWasm} from "./utils/wasmUtils";
import {drawGraph} from "./utils/utils";
import {Graph} from "nt-web-d3-graph";

const drawPanel = document.getElementById('draw-panel');
const WIDTH = drawPanel.clientWidth;
const HEIGHT = drawPanel.clientHeight;


loadWasm().then(wasm => {
  console.log('WASM loaded.');
  console.log('Ready to draw.');

  document.getElementById('draw-button').onclick = e => {
    const textArea = document.getElementById('graph-desc') as HTMLTextAreaElement;
    drawGraph(wasm, textArea.value);
  };
});

/* const graphdata = {
   'nodes':[
     {
       'index': 0,
       'visible': true,
       'name':'верхний',
       'id': 'n0',
       'related_links': ['n0n1'],
       'related_nodes': ['n1']
     },
     {
       'index': 1,
       'visible': true,
       'name':'средний',
       'id': 'n1',
       'related_links': ['n0n1'],
       'related_nodes': ['n0']
     },
     {
       'index': 2,
       'visible': true,
       'name':'нижний',
       'id': 'n2',
       'related_links': ['n1n2'],
       'related_nodes': ['n1']
     }
   ],
   'links':[
     {
       'visible': true,
       'id': 'n0n1',
       'source': 0,
       'target': 1
     },
     {
       'visible': true,
       'id': 'n1n2',
       'source': 1,
       'target': 2
     }
   ]
 };

 const configuration = {
   width: WIDTH,
   height: HEIGHT,
   graphId: drawPanel.id,
   element: drawPanel,
   vertex_mode: 'icon',
   arrangement_mode: 'custom',
   graphdata: graphdata,
   customArrangement: (graph) => {
     for (let i = 0; i < 3; i++) {
       graph.nodes[i].fx = 100;
       graph.nodes[i].cx = 100;
       graph.nodes[i].px = 100;

       let y = 0;
       if (i == 0) y = 100;
       else if (i == 1) y = 200;
       else if (i == 2) y = 500;
       graph.nodes[i].fy = y;
       graph.nodes[i].cy = y;
       graph.nodes[i].py = y;

       graph.nodes[i].fixed = true;
     }

   }
 };


 let graphInstance = new Graph(configuration);
 graphInstance.arrange(configuration.arrangement_mode);
*/

/*const graphdata = {
'nodes':[
{
'index': 0,
'visible': true,
'name':'верхний',
'id': 'n0',
'related_links': ['n0n1'],
'related_nodes': ['n1']
},
{
'index': 1,
'visible': true,
'name':'средний',
'id': 'n1',
'related_links': ['n0n1'],
'related_nodes': ['n0']
},
{
'index': 2,
'visible': true,
'name':'нижний',
'id': 'n2',
'related_links': ['n1n2'],
'related_nodes': ['n1']
}
],
'links':[
{
'visible': true,
'id': 'n0n1',
'source': 0,
'target': 1
},
{
'visible': true,
'id': 'n1n2',
'source': 1,
'target': 2
}
]
};

const configuration = {
width: WIDTH,
height: HEIGHT,
graphId: drawPanel.id,
element: drawPanel,
vertex_mode: 'icon',
arrangement_mode: 'custom',
graphdata: graphdata,
customArrangement: (graph) => {
graph.nodes[0].x = 100;
graph.nodes[0].y = 100;

graph.nodes[1].x = 100;
graph.nodes[1].y = 200;

graph.nodes[2].x = 100;
graph.nodes[2].y = 500;
}
};

let graphInstance = new Graph(configuration);
graphInstance.arrange(configuration.arrangement_mode);*/