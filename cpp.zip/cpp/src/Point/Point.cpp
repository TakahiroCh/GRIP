#include "Point.h"
using namespace std;

Point::Point(double x, double y) : x(x), y(y) { }

double Point::getX() const { return this->x; }
double Point::getY() const { return this->y; }

Point Point::operator+(const Point& p) const { return Point(this->x + p.getX(), this->y + p.getY()); }
Point Point::operator-(const Point& p) const { return Point(this->x - p.getX(), this->y - p.getY()); }

Point Point::operator*(double k) const { return Point(this->x * k, this->y * k); }

Point Point::operator/(double k) const { return Point(this->x / k, this->y / k); }

double Point::norm() const { return std::sqrt(this->x * this->x + this->y * this->y); }

std::ostream& operator<<(std::ostream& out, const Point& point) {
	out << "(" << point.getX() << ", " << point.getY() << ")";
	return out;
}

/*friend std::istream& operator>>(std::istream& in, Point& point) {
	in >> point->x >> point->y;
	return in;
}*/